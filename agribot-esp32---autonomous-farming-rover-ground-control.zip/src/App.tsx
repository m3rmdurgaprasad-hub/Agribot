import React, { useEffect, useState } from 'react';
import { esp32 } from './services/esp32Connection';
import { 
  BotMode, 
  ConnectionMode, 
  ConnectionStatus, 
  SeedLogEntry, 
  SerialLog, 
  TelemetryData 
} from './types/agribot';
import { Header } from './components/Header';
import { ModeSelector } from './components/ModeSelector';
import { PloughSeedController } from './components/PloughSeedController';
import { HarvestController } from './components/HarvestController';
import { FieldCanvas } from './components/FieldCanvas';
import { TelemetryGauges } from './components/TelemetryGauges';
import { ManualControls } from './components/ManualControls';
import { TerminalLogs } from './components/TerminalLogs';
import { HardwareWiringModal } from './components/HardwareWiringModal';
import { FirmwareModal } from './components/FirmwareModal';

export default function App() {
  const [telemetry, setTelemetry] = useState<TelemetryData>(esp32.getTelemetry());
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('CONNECTED');
  const [connectionMode, setConnectionMode] = useState<ConnectionMode>('SIMULATOR');
  const [currentMode, setCurrentMode] = useState<BotMode>(esp32.getMode());
  const [seedLogs, setSeedLogs] = useState<SeedLogEntry[]>(esp32.getSeedLogs());
  const [serialLogs, setSerialLogs] = useState<SerialLog[]>(esp32.getSerialLogs());

  // Modals
  const [isWiringModalOpen, setIsWiringModalOpen] = useState(false);
  const [isFirmwareModalOpen, setIsFirmwareModalOpen] = useState(false);

  useEffect(() => {
    const unsubTelemetry = esp32.subscribeTelemetry((data) => {
      setTelemetry(data);
    });

    const unsubStatus = esp32.subscribeStatus((status, mode) => {
      setConnectionStatus(status);
      setConnectionMode(mode);
    });

    const unsubLogs = esp32.subscribeLogs((newLog) => {
      setSerialLogs([...esp32.getSerialLogs()]);
    });

    const unsubSeedLogs = esp32.subscribeSeedLogs((logs) => {
      setSeedLogs(logs);
    });

    return () => {
      unsubTelemetry();
      unsubStatus();
      unsubLogs();
      unsubSeedLogs();
    };
  }, []);

  const handleSelectMode = (mode: BotMode) => {
    setCurrentMode(mode);
    esp32.setMode(mode);
  };

  const handleEmergencyStop = () => {
    setCurrentMode('EMERGENCY_STOP');
    esp32.emergencyStop();
  };

  const handleConnectSerial = async () => {
    await esp32.connectWebSerial();
  };

  const handleConnectWifi = async (ip: string) => {
    await esp32.connectWebSocket(ip, 81);
  };

  const handleDisconnect = () => {
    esp32.disconnect();
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        telemetry={telemetry}
        connectionStatus={connectionStatus}
        connectionMode={connectionMode}
        currentMode={currentMode}
        onConnectSerial={handleConnectSerial}
        onConnectWifi={handleConnectWifi}
        onDisconnect={handleDisconnect}
        onEmergencyStop={handleEmergencyStop}
        onOpenWiringGuide={() => setIsWiringModalOpen(true)}
        onOpenFirmware={() => setIsFirmwareModalOpen(true)}
      />

      {/* Main Ground Station Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-6 space-y-6">
        {/* Mission Mode Selection Bar */}
        <section>
          <ModeSelector
            currentMode={currentMode}
            onSelectMode={handleSelectMode}
          />
        </section>

        {/* Real-time Telemetry Sensor Gauges */}
        <section>
          <TelemetryGauges telemetry={telemetry} />
        </section>

        {/* Dynamic Mode Controller Section */}
        {/* If user picks Plough Mode -> Show precision stepped Plough & Seeder controller with distance calculation, stopped drill, and auto-irrigation */}
        {currentMode === 'PLOUGH_SEED' && (
          <section className="animate-in fade-in slide-in-from-top-2 duration-300">
            <PloughSeedController
              telemetry={telemetry}
              seedLogs={seedLogs}
              onUpdateSeedSpacing={(cm) => esp32.updateSettings({ defaultSeedSpacingCm: cm })}
              onUpdateMoistureThreshold={(th) => esp32.updateSettings({ autoIrrigateMoistureThreshold: th })}
              onTriggerManualDrill={() => esp32.manualTriggerDrill()}
              onTriggerManualPump={() => esp32.manualTriggerPump(2.0)}
            />
          </section>
        )}

        {/* If user picks Harvest Mode -> Show front motor harvester blades controller */}
        {currentMode === 'HARVEST' && (
          <section className="animate-in fade-in slide-in-from-top-2 duration-300">
            <HarvestController
              telemetry={telemetry}
              onToggleBlade={() => esp32.toggleHarvesterBlade()}
              onSetRpm={(rpm) => esp32.setHarvesterRpm(rpm)}
              onSetCrawlSpeed={(pwm) => {
                const t = esp32.getTelemetry();
                t.harvestCrawlSpeedPwm = pwm;
              }}
            />
          </section>
        )}

        {/* Visual 2D Field Plot Canvas & Autonomous Twin */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          <div className="lg:col-span-2">
            <FieldCanvas
              telemetry={telemetry}
              seedLogs={seedLogs}
            />
          </div>

          {/* Quick Actuator Overrides & Status in Sidebar */}
          <div className="space-y-4">
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">
                AgriBot Real-Time Status Summary
              </h3>

              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between p-2 rounded bg-slate-950 border border-slate-800/80">
                  <span className="text-slate-400">MISSION STATE:</span>
                  <span className="text-emerald-400 font-bold">{currentMode}</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950 border border-slate-800/80">
                  <span className="text-slate-400">SEED DRILL SERVO (D9):</span>
                  <span className={telemetry.seedDrillActive ? 'text-amber-400 font-bold' : 'text-slate-400'}>
                    {telemetry.seedDrillActive ? '90° (DOWN)' : '0° (RETRACTED)'}
                  </span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950 border border-slate-800/80">
                  <span className="text-slate-400">12V WATER PUMP RELAY:</span>
                  <span className={telemetry.pumpActive ? 'text-cyan-400 font-bold animate-pulse' : 'text-slate-400'}>
                    {telemetry.pumpActive ? 'ACTIVE (PUMPING)' : 'STANDBY'}
                  </span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950 border border-slate-800/80">
                  <span className="text-slate-400">HARVESTER BLADE MOTOR:</span>
                  <span className={telemetry.harvesterBladeActive ? 'text-amber-400 font-bold' : 'text-slate-400'}>
                    {telemetry.harvesterBladeActive ? `${telemetry.harvesterBladeRpm} RPM` : 'STOPPED'}
                  </span>
                </div>
                <div className="flex justify-between p-2 rounded bg-slate-950 border border-slate-800/80">
                  <span className="text-slate-400">L298N DRIVE MOTORS:</span>
                  <span className={telemetry.roverSpeedPwm > 0 ? 'text-emerald-400' : 'text-slate-400 font-bold'}>
                    {telemetry.roverSpeedPwm > 0 ? `${telemetry.roverSpeedPwm} PWM` : 'STOPPED (0 RPM)'}
                  </span>
                </div>
              </div>

              {/* Quick Mode Switches */}
              <div className="pt-2 border-t border-slate-800 flex gap-2">
                <button
                  onClick={() => handleSelectMode('PLOUGH_SEED')}
                  className="flex-1 py-1.5 px-2 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 rounded text-xs font-semibold transition-colors"
                >
                  Plough &amp; Seed
                </button>
                <button
                  onClick={() => handleSelectMode('HARVEST')}
                  className="flex-1 py-1.5 px-2 bg-amber-950 hover:bg-amber-900 border border-amber-800 text-amber-300 rounded text-xs font-semibold transition-colors"
                >
                  Harvest Mode
                </button>
              </div>
            </div>

            {/* Quick Link to Hardware Blueprint */}
            <div 
              onClick={() => setIsWiringModalOpen(true)}
              className="p-3.5 bg-gradient-to-r from-emerald-950/40 to-slate-900 border border-emerald-900/60 rounded-xl cursor-pointer hover:border-emerald-600 transition-all text-xs flex items-center justify-between"
            >
              <div>
                <span className="font-bold text-emerald-300 block">
                  Inspect Rover Wiring Diagram
                </span>
                <span className="text-slate-400 text-[11px]">
                  L298N, Uno/ESP32, Servo, Soil probe &amp; 12V battery guide
                </span>
              </div>
              <span className="text-emerald-400 text-base font-bold">›</span>
            </div>
          </div>
        </section>

        {/* Manual Teleoperation & Serial Logs Grid */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          <ManualControls
            telemetry={telemetry}
            onDrive={(dir, spd) => esp32.manualDrive(dir, spd)}
            onToggleBlade={() => esp32.toggleHarvesterBlade()}
            onTriggerPump={() => esp32.manualTriggerPump(2.0)}
            onTriggerDrill={() => esp32.manualTriggerDrill()}
          />

          <TerminalLogs
            logs={serialLogs}
            onSendCommand={(cmd) => esp32.addLog('TX', cmd)}
          />
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 px-4 py-4 text-center text-xs text-slate-500 font-mono">
        AgriBot Autonomous Farming Rover · ESP32 / Arduino Uno Ground Teleoperation Console · Built for Precision Agriculture
      </footer>

      {/* Hardware Wiring Modal */}
      <HardwareWiringModal
        isOpen={isWiringModalOpen}
        onClose={() => setIsWiringModalOpen(false)}
      />

      {/* ESP32 Arduino Firmware Code Modal */}
      <FirmwareModal
        isOpen={isFirmwareModalOpen}
        onClose={() => setIsFirmwareModalOpen(false)}
      />
    </div>
  );
}
