import React, { useRef } from 'react';
import { TelemetryData, SeedLogEntry } from '../types/agribot';
import { Compass, Maximize2, RotateCcw, Sprout, Wheat, Droplets } from 'lucide-react';

interface FieldCanvasProps {
  telemetry: TelemetryData;
  seedLogs: SeedLogEntry[];
  onResetPosition?: () => void;
}

export const FieldCanvas: React.FC<FieldCanvasProps> = ({
  telemetry,
  seedLogs,
  onResetPosition,
}) => {
  const isHarvesterActive = telemetry.harvesterBladeActive;
  const isSeedDrillActive = telemetry.seedDrillActive;
  const isPumpActive = telemetry.pumpActive;

  // Rover coordinates scaled to SVG viewBox 0 0 100 100
  const roverX = telemetry.position.x;
  const roverY = telemetry.position.y;
  const heading = telemetry.position.headingDeg;

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-xl flex flex-col justify-between relative overflow-hidden">
      {/* Canvas Top Bar */}
      <div className="flex items-center justify-between mb-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-200 flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-emerald-400" />
            Field Autonomous Plot Grid (10m x 10m)
          </span>
          <span className="text-slate-500 font-mono text-[11px] hidden sm:inline">
            [X: {roverX.toFixed(1)}m, Y: {roverY.toFixed(1)}m, Heading: {heading}°]
          </span>
        </div>

        <div className="flex items-center gap-2 font-mono text-[11px]">
          <div className="flex items-center gap-1 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Seed Spot</span>
          </div>
          <div className="flex items-center gap-1 text-cyan-400">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>Irrigated</span>
          </div>
          <div className="flex items-center gap-1 text-amber-400">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>Harvested</span>
          </div>
        </div>
      </div>

      {/* SVG Agricultural Field Plot */}
      <div className="w-full aspect-video sm:aspect-[16/9] lg:aspect-[2/1] bg-[#121c15] rounded-lg border border-emerald-950/80 relative overflow-hidden shadow-inner">
        <svg 
          viewBox="0 0 100 60" 
          className="w-full h-full select-none"
        >
          {/* Soil Furrow Rows */}
          <defs>
            <pattern id="soilTexture" width="4" height="4" patternUnits="userSpaceOnUse">
              <path d="M 0 2 L 4 2" stroke="#1b2a20" strokeWidth="0.8" />
            </pattern>
            {/* Harvester blade spin gradient */}
            <radialGradient id="bladeSpinGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Soil background grid */}
          <rect width="100" height="60" fill="#0f1912" />
          <rect width="100" height="60" fill="url(#soilTexture)" />

          {/* Cultivated Furrow Lines (Every 10 units) */}
          {[10, 20, 30, 40, 50].map((y) => (
            <line
              key={y}
              x1="2"
              y1={y}
              x2="98"
              y2={y}
              stroke="#263b2d"
              strokeWidth="1.2"
              strokeDasharray="1.5 1.5"
            />
          ))}

          {/* Planted Crops / Seed markers */}
          {seedLogs.map((log) => (
            <g key={log.id} transform={`translate(${log.x}, ${log.y * 0.6})`}>
              {/* Seed dot */}
              <circle
                r="1.2"
                fill={log.irrigated ? '#06b6d4' : '#10b981'}
                stroke="#022c22"
                strokeWidth="0.3"
              />
              {log.irrigated && (
                <circle
                  r="2.5"
                  fill="none"
                  stroke="#06b6d4"
                  strokeWidth="0.4"
                  opacity="0.6"
                  strokeDasharray="0.8 0.8"
                />
              )}
            </g>
          ))}

          {/* Harvested Area swath trail */}
          {telemetry.harvesterBladeActive && (
            <path
              d={`M 10 24 L ${roverX} 24`}
              stroke="#f59e0b"
              strokeWidth="4"
              opacity="0.25"
              strokeLinecap="round"
            />
          )}

          {/* Water Spray Mist Cloud when pump active */}
          {isPumpActive && (
            <g transform={`translate(${roverX}, ${roverY * 0.6})`}>
              <circle r="7" fill="#06b6d4" opacity="0.25" className="animate-ping" />
              <circle r="5" fill="#38bdf8" opacity="0.35" />
              <text x="7" y="-2" fill="#38bdf8" fontSize="2.2" fontFamily="monospace" fontWeight="bold">
                12V PUMP SPRAYING
              </text>
            </g>
          )}

          {/* ROVER VEHICLE CHASSIS */}
          <g 
            transform={`translate(${roverX}, ${roverY * 0.6}) rotate(${heading - 90})`}
            className="transition-transform duration-300 ease-out"
          >
            {/* FRONT HARVESTER CUTTER BLADES */}
            <g transform="translate(0, -5.5)">
              {/* Harvester Mount Bracket */}
              <rect x="-4.5" y="-1.5" width="9" height="1.8" fill="#334155" rx="0.4" stroke="#64748b" strokeWidth="0.2" />
              
              {/* Spinning cutter blades */}
              <g className={isHarvesterActive ? 'animate-spin' : ''} style={{ transformOrigin: '0px 0px', animationDuration: '0.25s' }}>
                {/* 3-bladed rotating cutter */}
                <line x1="-4" y1="0" x2="4" y2="0" stroke={isHarvesterActive ? '#f59e0b' : '#94a3b8'} strokeWidth="1" strokeLinecap="round" />
                <line x1="0" y1="-4" x2="0" y2="4" stroke={isHarvesterActive ? '#f59e0b' : '#94a3b8'} strokeWidth="1" strokeLinecap="round" />
                <circle r="1" fill="#475569" stroke="#cbd5e1" strokeWidth="0.3" />
              </g>

              {/* Cutting blur halo when active */}
              {isHarvesterActive && (
                <circle r="4.2" fill="url(#bladeSpinGlow)" />
              )}
            </g>

            {/* Ultrasonic HC-SR04 Sensor on front bumper */}
            <g transform="translate(0, -4.2)">
              <rect x="-2" y="-0.8" width="4" height="1.2" fill="#0284c7" rx="0.3" />
              <circle cx="-1" cy="-0.2" r="0.5" fill="#e0f2fe" />
              <circle cx="1" cy="-0.2" r="0.5" fill="#e0f2fe" />
            </g>

            {/* 4 DC Geared Wheels (Yellow Hubs like diagram!) */}
            {/* Front Left */}
            <rect x="-4.8" y="-4" width="1.5" height="3" fill="#1e293b" rx="0.5" stroke="#eab308" strokeWidth="0.4" />
            {/* Front Right */}
            <rect x="3.3" y="-4" width="1.5" height="3" fill="#1e293b" rx="0.5" stroke="#eab308" strokeWidth="0.4" />
            {/* Rear Left */}
            <rect x="-4.8" y="1" width="1.5" height="3" fill="#1e293b" rx="0.5" stroke="#eab308" strokeWidth="0.4" />
            {/* Rear Right */}
            <rect x="3.3" y="1" width="1.5" height="3" fill="#1e293b" rx="0.5" stroke="#eab308" strokeWidth="0.4" />

            {/* Main Aluminium Chassis */}
            <rect x="-3.5" y="-3.5" width="7" height="7" fill="#0f172a" rx="1" stroke="#334155" strokeWidth="0.5" />

            {/* 10W Solar Panel (Blue silicon grid on top) */}
            <rect x="-2.8" y="-2.8" width="5.6" height="5.6" fill="#1e3a8a" rx="0.4" stroke="#60a5fa" strokeWidth="0.3" />
            <line x1="-2.8" y1="0" x2="2.8" y2="0" stroke="#93c5fd" strokeWidth="0.2" opacity="0.6" />
            <line x1="0" y1="-2.8" x2="0" y2="2.8" stroke="#93c5fd" strokeWidth="0.2" opacity="0.6" />

            {/* REAR SEED DRILL MECHANISM (MG996R Servo + Drill Spout) */}
            <g transform="translate(0, 4.2)">
              <rect x="-1.8" y="-0.5" width="3.6" height="1.6" fill="#475569" rx="0.3" />
              {/* Servo arm drill point */}
              <circle 
                cx="0" 
                cy="1" 
                r={isSeedDrillActive ? '1.4' : '0.8'} 
                fill={isSeedDrillActive ? '#eab308' : '#64748b'} 
                stroke="#fef08a" 
                strokeWidth="0.3"
                className={isSeedDrillActive ? 'animate-ping' : ''} 
              />
            </g>

            {/* Forward Orientation Heading Arrow */}
            <polygon points="0,-4.5 -1.2,-2.5 1.2,-2.5" fill="#10b981" />
          </g>
        </svg>

        {/* Live Overlay Badges in the Canvas */}
        <div className="absolute bottom-2 left-2 flex items-center gap-2">
          {isHarvesterActive && (
            <div className="px-2 py-1 rounded bg-amber-950/90 border border-amber-600/80 text-[11px] font-mono text-amber-300 flex items-center gap-1.5 shadow-lg backdrop-blur">
              <Wheat className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              <span>Harvester Blades Rotating: {telemetry.harvesterBladeRpm} RPM</span>
            </div>
          )}

          {isSeedDrillActive && (
            <div className="px-2 py-1 rounded bg-emerald-950/90 border border-emerald-600/80 text-[11px] font-mono text-emerald-300 flex items-center gap-1.5 shadow-lg backdrop-blur">
              <Sprout className="w-3.5 h-3.5 text-emerald-400" />
              <span>Drill Plunged · Motors STOPPED</span>
            </div>
          )}

          {isPumpActive && (
            <div className="px-2 py-1 rounded bg-cyan-950/90 border border-cyan-600/80 text-[11px] font-mono text-cyan-300 flex items-center gap-1.5 shadow-lg backdrop-blur">
              <Droplets className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>Auto-Irrigation: Dispensing Water</span>
            </div>
          )}
        </div>

        {/* Real-time coordinates in bottom-right */}
        <div className="absolute bottom-2 right-2 px-2 py-1 rounded bg-slate-950/90 border border-slate-800 text-[11px] font-mono text-slate-400 backdrop-blur">
          GPS: {telemetry.gps.lat.toFixed(4)}°N, {telemetry.gps.lng.toFixed(4)}°E (Sats: {telemetry.gps.satellites})
        </div>
      </div>
    </div>
  );
};
