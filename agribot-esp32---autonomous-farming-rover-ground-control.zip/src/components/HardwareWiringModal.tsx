import React, { useState } from 'react';
import { 
  X, 
  Cpu, 
  Zap, 
  Sliders, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  ExternalLink,
  ChevronRight,
  Info
} from 'lucide-react';

interface HardwareWiringModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HardwareWiringModal: React.FC<HardwareWiringModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'wiring' | 'tools' | 'bom'>('wiring');

  if (!isOpen) return null;

  const pinMappings = [
    { module: 'L298N ENA (Speed 1 & 2)', arduino: 'D5 (PWM)', esp32: 'GPIO 21', note: 'Left motors speed control' },
    { module: 'L298N IN1 (Motor 1 Front Left)', arduino: 'D6', esp32: 'GPIO 19', note: 'Direction pin A' },
    { module: 'L298N IN2 (Motor 1 Front Left)', arduino: 'D7', esp32: 'GPIO 18', note: 'Direction pin B' },
    { module: 'L298N IN3 (Motor 2 Rear Left)', arduino: 'D8', esp32: 'GPIO 5', note: 'Direction pin A' },
    { module: 'L298N IN4 (Motor 2 Rear Left)', arduino: 'D9', esp32: 'GPIO 17', note: 'Direction pin B' },
    { module: 'L298N ENB (Speed 3 & 4)', arduino: 'D10 (PWM)', esp32: 'GPIO 22', note: 'Right motors speed control' },
    { module: 'L298N IN1 (Motor 3 Front Right)', arduino: 'D11', esp32: 'GPIO 16', note: 'Direction pin A' },
    { module: 'L298N IN2 (Motor 3 Front Right)', arduino: 'D12', esp32: 'GPIO 4', note: 'Direction pin B' },
    { module: 'L298N IN3 (Motor 4 Rear Right)', arduino: 'D13', esp32: 'GPIO 2', note: 'Direction pin A' },
    { module: 'L298N IN4 (Motor 4 Rear Right)', arduino: 'D2', esp32: 'GPIO 15', note: 'Direction pin B' },
    { module: 'Seed Drill Servo (MG996R/SG90)', arduino: 'D9 / Signal', esp32: 'GPIO 13', note: 'Rotates 90° for drill plunge & seed drop' },
    { module: 'Soil Moisture Sensor (AO)', arduino: 'A0 (Analog)', esp32: 'GPIO 34 (ADC1)', note: 'Continuous VWC moisture % sampling' },
    { module: '12V Water Pump Relay', arduino: 'D4', esp32: 'GPIO 26', note: 'Automated furrow irrigation when soil dry' },
    { module: 'Front Harvester Blade Motor', arduino: 'D3 (PWM)', esp32: 'GPIO 25 (PWM)', note: 'High-torque front rotating cutter blades' },
    { module: 'HC-SR04 Ultrasonic Trig / Echo', arduino: 'A1 / A2', esp32: 'GPIO 14 / GPIO 27', note: 'Front collision safety radar' },
  ];

  const toolsList = [
    { name: 'Plough Tool', desc: 'Front/rear chisels to loosen hard topsoil and create optimal furrow lines for seeding.' },
    { name: 'Precision Seeder', desc: 'Dispenses seeds at exact calculated distance intervals with stationary drill plunge.' },
    { name: 'Smart Furrow Sprayer / Pump', desc: '12V DC water pump with fine mist nozzle triggered when soil moisture drops below threshold.' },
    { name: 'Front Rotary Harvester', desc: 'High-torque DC motor with spinning blades to harvest mature crops along furrow rows.' },
    { name: 'Fertilizer Spreader', desc: 'Rotary dispenser applying micro-fertilizer granules precisely to seed beds.' },
    { name: 'Weed Removal Arm', desc: 'Camera/AI vision guided spot-weeding tool to eradicate invasive plants.' },
    { name: 'ESP32-CAM Inspector', desc: 'Visual AI crop health, pest recognition, and live telemetry video stream.' },
  ];

  const bomList = [
    { item: 'ESP32 NodeMCU (or Arduino Uno)', qty: '1', approxCost: '₹600 / $8' },
    { item: 'L298N Dual H-Bridge Motor Driver', qty: '1', approxCost: '₹200 / $3' },
    { item: 'DC Geared Motors (12V High-Torque)', qty: '4', approxCost: '₹1,200 / $15' },
    { item: 'Rugged Farming Wheels (with tyres)', qty: '4', approxCost: '₹800 / $10' },
    { item: '12V Rechargeable Battery Pack', qty: '1', approxCost: '₹800 / $10' },
    { item: '10W Monocrystalline Solar Panel', qty: '1', approxCost: '₹700 / $9' },
    { item: 'Capacitive Soil Moisture Sensor', qty: '1', approxCost: '₹150 / $2' },
    { item: 'Front Harvester DC Motor + Blades', qty: '1', approxCost: '₹450 / $6' },
    { item: '12V Submersible Water Pump + Tubing', qty: '1', approxCost: '₹350 / $4' },
    { item: 'MG996R Metal Gear Servo (for drill)', qty: '1', approxCost: '₹250 / $3' },
    { item: 'HC-SR04 Ultrasonic Distance Sensor', qty: '1', approxCost: '₹100 / $1' },
    { item: 'Aluminium / Acrylic Chassis Frame', qty: '1', approxCost: '₹600 / $8' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
                AgriBot Hardware & Wiring Blueprint
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-300">
                  L298N · ESP32 · Sensors
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Official schematic connection table & interchangeable tool system architecture
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-5 pt-2 gap-2 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('wiring')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'wiring'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Pinout & Electrical Connections
          </button>
          <button
            onClick={() => setActiveTab('tools')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'tools'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Modular Tool Attachments (7 Tools)
          </button>
          <button
            onClick={() => setActiveTab('bom')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'bom'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Components & Cost Summary
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {activeTab === 'wiring' && (
            <div className="space-y-4">
              {/* Critical wiring rules from diagram */}
              <div className="p-3.5 rounded-lg bg-emerald-950/30 border border-emerald-800/80 text-emerald-300 space-y-1.5">
                <div className="font-bold flex items-center gap-1.5 text-emerald-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Key Wiring Points from AgriBot Schematic:
                </div>
                <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                  <li><strong className="text-emerald-300">Dedicated 12V Power:</strong> Use a separate 12V rechargeable battery pack for motors and pump (avoid 9V PP3 batteries).</li>
                  <li><strong className="text-emerald-300">Common Ground:</strong> Connect battery GND, L298N GND, ESP32 GND, and sensor GND together.</li>
                  <li><strong className="text-emerald-300">5V Jumper on L298N:</strong> Keep the 5V jumper installed on L298N so its onboard regulator supplies 5V to the ESP32/Arduino and Servo.</li>
                  <li><strong className="text-emerald-300">Seed Drill Servo:</strong> Signal wire goes to D9 (Arduino) or GPIO 13 (ESP32).</li>
                  <li><strong className="text-emerald-300">Soil Moisture:</strong> AO connected to ADC pin for precision 0-100% moisture reading.</li>
                </ul>
              </div>

              {/* Pin mapping table */}
              <div className="border border-slate-800 rounded-lg overflow-hidden">
                <table className="w-full text-left font-mono text-[11px]">
                  <thead className="bg-slate-950 text-slate-400">
                    <tr>
                      <th className="p-2.5">Component / Module</th>
                      <th className="p-2.5">Arduino Uno Pin</th>
                      <th className="p-2.5">ESP32 Pin</th>
                      <th className="p-2.5">Function & Role</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 bg-slate-900/50">
                    {pinMappings.map((pin, i) => (
                      <tr key={i} className="hover:bg-slate-800/40">
                        <td className="p-2.5 font-sans font-medium text-slate-200">{pin.module}</td>
                        <td className="p-2.5 text-cyan-400">{pin.arduino}</td>
                        <td className="p-2.5 text-emerald-400 font-bold">{pin.esp32}</td>
                        <td className="p-2.5 font-sans text-slate-400">{pin.note}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'tools' && (
            <div className="space-y-3">
              <p className="text-slate-300 leading-relaxed">
                AgriBot features a quick-swap tool chassis permitting the rover to perform every stage of the farming cycle autonomously:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {toolsList.map((tool, i) => (
                  <div key={i} className="p-3 rounded-lg bg-slate-950/70 border border-slate-800 space-y-1">
                    <span className="font-bold text-slate-200 text-xs block text-emerald-400">
                      #{i + 1} · {tool.name}
                    </span>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      {tool.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'bom' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800">
                <span className="font-bold text-slate-200">
                  Total Estimated Hardware Cost:
                </span>
                <span className="font-mono text-base font-bold text-emerald-400">
                  ₹10,000 – ₹12,000 (~$120 - $145 USD)
                </span>
              </div>

              <div className="border border-slate-800 rounded-lg overflow-hidden">
                <table className="w-full text-left font-mono text-[11px]">
                  <thead className="bg-slate-950 text-slate-400">
                    <tr>
                      <th className="p-2.5">Item Description</th>
                      <th className="p-2.5">Quantity</th>
                      <th className="p-2.5">Approx. Cost</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 bg-slate-900/50 font-sans">
                    {bomList.map((bom, i) => (
                      <tr key={i} className="hover:bg-slate-800/40">
                        <td className="p-2.5 text-slate-200">{bom.item}</td>
                        <td className="p-2.5 font-mono text-slate-400">{bom.qty}</td>
                        <td className="p-2.5 font-mono text-emerald-400 font-semibold">{bom.approxCost}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <span className="text-[11px] text-slate-400">
            Ground Control Ready · Compatible with ESP32 & Arduino Uno
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
