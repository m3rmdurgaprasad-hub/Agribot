import React from 'react';
import { TelemetryData } from '../types/agribot';
import { 
  Wheat, 
  RotateCw, 
  AlertTriangle, 
  Gauge, 
  Zap, 
  Sliders, 
  ShieldCheck,
  Radar
} from 'lucide-react';

interface HarvestControllerProps {
  telemetry: TelemetryData;
  onToggleBlade: () => void;
  onSetRpm: (rpm: number) => void;
  onSetCrawlSpeed: (pwm: number) => void;
}

export const HarvestController: React.FC<HarvestControllerProps> = ({
  telemetry,
  onToggleBlade,
  onSetRpm,
  onSetCrawlSpeed,
}) => {
  const isBladeActive = telemetry.harvesterBladeActive;
  const currentRpm = telemetry.harvesterBladeRpm;
  const rpmPercent = Math.min(100, (currentRpm / 1800) * 100);

  return (
    <div className="bg-slate-900/80 border border-amber-900/50 rounded-xl p-4 lg:p-5 shadow-xl space-y-5">
      {/* Header and status banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3.5">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400">
            <Wheat className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100">
                Front Harvester Blade Cutting System
              </h3>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-amber-950 border border-amber-800 text-amber-300 font-semibold">
                Front High-Torque Motor Active
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Rotary cutting blade control · Crop swath clearing · Forward crawl speed synchronization
            </p>
          </div>
        </div>

        {/* Swath & Yield Counters */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="bg-slate-950 px-3 py-1.5 rounded-md border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Harvested Area</span>
            <span className="text-amber-400 text-base font-bold">{telemetry.harvestedAreaSqM.toFixed(1)} m²</span>
          </div>
          <div className="bg-slate-950 px-3 py-1.5 rounded-md border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Blade Status</span>
            <span className={`text-base font-bold ${isBladeActive ? 'text-amber-400' : 'text-slate-500'}`}>
              {isBladeActive ? 'SPINNING' : 'STOPPED'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Tachometer & Blade Control Visualizer */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Blade Tachometer & Power Box */}
        <div className="p-4 rounded-lg bg-slate-950/80 border border-slate-800 space-y-3 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
              <RotateCw className={`w-4 h-4 text-amber-400 ${isBladeActive ? 'animate-spin' : ''}`} style={{ animationDuration: '0.6s' }} />
              <span>Front Cutter Blades</span>
            </div>
            <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
              isBladeActive ? 'bg-amber-950 text-amber-300 border border-amber-700' : 'bg-slate-900 text-slate-500'
            }`}>
              {isBladeActive ? 'MOTOR ENGAGED' : 'DISENGAGED'}
            </span>
          </div>

          <div className="py-2 text-center">
            <div className="text-3xl font-mono font-extrabold text-amber-400 tracking-tight">
              {currentRpm} <span className="text-xs font-normal text-slate-400">RPM</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {isBladeActive ? 'High-velocity rotating crop cutter blades' : 'Blades safely locked'}
            </div>
          </div>

          {/* RPM Bar */}
          <div className="space-y-1">
            <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800">
              <div 
                className={`h-2.5 transition-all duration-300 ${
                  rpmPercent > 80 ? 'bg-amber-400' : 'bg-amber-500'
                }`}
                style={{ width: `${rpmPercent}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>0 RPM</span>
              <span>900 RPM</span>
              <span>1800 RPM (Max)</span>
            </div>
          </div>

          <button
            onClick={onToggleBlade}
            className={`w-full py-2.5 rounded-lg font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
              isBladeActive
                ? 'bg-red-900/60 hover:bg-red-800 text-red-200 border border-red-700'
                : 'bg-amber-600 hover:bg-amber-500 text-slate-950 shadow-lg shadow-amber-950/60'
            }`}
          >
            <RotateCw className={`w-3.5 h-3.5 ${isBladeActive ? 'animate-spin' : ''}`} />
            {isBladeActive ? 'Disengage Front Harvester Motor' : 'Engage Front Harvester Blades'}
          </button>
        </div>

        {/* Speed & PWM Sliders */}
        <div className="p-4 rounded-lg bg-slate-950/80 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>Harvester PWM & Velocity Calibration</span>
          </div>

          {/* Blade RPM Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Front Blade PWM Target:</span>
              <span className="font-mono text-amber-400 font-bold">{currentRpm} RPM</span>
            </div>
            <input
              type="range"
              min="0"
              max="1800"
              step="100"
              value={currentRpm}
              onChange={(e) => onSetRpm(parseInt(e.target.value, 10))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>Stalk Trimming (800)</span>
              <span>Standard (1400)</span>
              <span>Dense Crop (1800)</span>
            </div>
          </div>

          {/* Forward Crawl Speed */}
          <div className="space-y-1.5 pt-2 border-t border-slate-800">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Rover Harvest Crawl Speed:</span>
              <span className="font-mono text-slate-200 font-bold">PWM {telemetry.harvestCrawlSpeedPwm}</span>
            </div>
            <input
              type="range"
              min="60"
              max="200"
              step="10"
              value={telemetry.harvestCrawlSpeedPwm}
              onChange={(e) => onSetCrawlSpeed(parseInt(e.target.value, 10))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>Low Crawl (80)</span>
              <span>Moderate (120)</span>
              <span>Rapid (180)</span>
            </div>
          </div>
        </div>

        {/* Ultrasonic Front Radar & Safety Clearance */}
        <div className="p-4 rounded-lg bg-slate-950/80 border border-slate-800 space-y-3 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
              <Radar className="w-4 h-4 text-cyan-400" />
              <span>Front Obstacle Guard</span>
            </div>
            <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
              telemetry.obstacleDetected ? 'bg-red-950 text-red-400 border border-red-800 animate-pulse' : 'bg-emerald-950 text-emerald-400'
            }`}>
              {telemetry.obstacleDetected ? 'COLLISION STOP' : 'CLEAR PATH'}
            </span>
          </div>

          <div className="py-2 text-center">
            <div className={`text-2xl font-mono font-extrabold ${telemetry.obstacleDetected ? 'text-red-400' : 'text-cyan-400'}`}>
              {telemetry.ultrasonicDistanceCm} <span className="text-xs font-normal text-slate-400">cm</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              HC-SR04 forward distance from cutter blade tip
            </div>
          </div>

          <div className="p-2.5 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-400 space-y-1">
            <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Harvester Safety Protocol:
            </div>
            <p className="leading-tight text-slate-400">
              Rover will immediately halt drive motor forward motion if obstacles or large rocks are detected under 25 cm from blades.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
