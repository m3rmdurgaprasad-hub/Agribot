import React, { useState } from 'react';
import { 
  BotMode, 
  ConnectionMode, 
  ConnectionStatus, 
  TelemetryData 
} from '../types/agribot';
import { 
  Sprout, 
  Wifi, 
  Usb, 
  ShieldAlert, 
  Cpu, 
  Sun, 
  Battery, 
  Code2, 
  HelpCircle,
  Activity,
  Layers
} from 'lucide-react';

interface HeaderProps {
  telemetry: TelemetryData;
  connectionStatus: ConnectionStatus;
  connectionMode: ConnectionMode;
  currentMode: BotMode;
  onConnectSerial: () => void;
  onConnectWifi: (ip: string) => void;
  onDisconnect: () => void;
  onEmergencyStop: () => void;
  onOpenWiringGuide: () => void;
  onOpenFirmware: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  telemetry,
  connectionStatus,
  connectionMode,
  currentMode,
  onConnectSerial,
  onConnectWifi,
  onDisconnect,
  onEmergencyStop,
  onOpenWiringGuide,
  onOpenFirmware,
}) => {
  const [showWifiPrompt, setShowWifiPrompt] = useState(false);
  const [wifiIp, setWifiIp] = useState('192.168.4.1');

  const handleWifiSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (wifiIp.trim()) {
      onConnectWifi(wifiIp.trim());
      setShowWifiPrompt(false);
    }
  };

  return (
    <header className="border-b border-emerald-950/80 bg-slate-950/95 backdrop-blur-md sticky top-0 z-40 px-4 lg:px-8 py-3.5 shadow-xl">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Brand & Mission Status */}
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-inner">
            <Sprout className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-tight text-lg text-slate-100 flex items-center gap-1.5">
                AgriBot
                <span className="text-emerald-400 text-xs font-mono font-semibold px-1.5 py-0.5 rounded bg-emerald-950/70 border border-emerald-800/60">
                  ESP32 ROVER
                </span>
              </span>
              <span className="text-xs text-slate-500 hidden sm:inline">·</span>
              <span className="text-xs font-mono text-slate-400 hidden sm:inline">
                Firmware v2.4-RT
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Autonomous Precision Farming & Teleoperation Control
            </p>
          </div>
        </div>

        {/* Telemetry Quick Badges */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-4">
          {/* Battery Status */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs font-mono">
            <Battery className={`w-3.5 h-3.5 ${telemetry.batteryPercent < 20 ? 'text-red-400' : 'text-emerald-400'}`} />
            <span className="text-slate-300 font-semibold">{telemetry.batteryVoltage.toFixed(1)}V</span>
            <span className="text-slate-500">({Math.round(telemetry.batteryPercent)}%)</span>
          </div>

          {/* Solar Panel */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs font-mono">
            <Sun className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: '14s' }} />
            <span className="text-amber-300 font-semibold">{telemetry.solarWatts}W</span>
            <span className="text-slate-500 hidden sm:inline">Solar</span>
          </div>

          {/* Soil Moisture Mini Badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs font-mono">
            <span className={`w-2 h-2 rounded-full ${telemetry.soilMoisture < telemetry.moistureThreshold ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
            <span className="text-slate-400">Moisture:</span>
            <span className={`font-semibold ${telemetry.soilMoisture < telemetry.moistureThreshold ? 'text-amber-400' : 'text-emerald-400'}`}>
              {telemetry.soilMoisture}%
            </span>
          </div>

          {/* Active Mode Badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900/90 border border-emerald-900/60 text-xs font-mono">
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-400">Mode:</span>
            <span className="font-bold text-emerald-300 uppercase">
              {currentMode.replace('_', ' ')}
            </span>
          </div>
        </div>

        {/* Action Controls & Emergency Stop */}
        <div className="flex items-center gap-2">
          {/* Connection Trigger Buttons */}
          {connectionMode === 'SIMULATOR' ? (
            <div className="flex items-center gap-1.5">
              <button
                onClick={onConnectSerial}
                title="Connect via USB Web Serial (115200 baud)"
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-700/60 text-emerald-300 transition-colors"
              >
                <Usb className="w-3.5 h-3.5 text-emerald-400" />
                <span>USB Serial</span>
              </button>

              <button
                onClick={() => setShowWifiPrompt(!showWifiPrompt)}
                title="Connect via ESP32 WiFi WebSocket"
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 transition-colors"
              >
                <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                <span>WiFi WS</span>
              </button>
            </div>
          ) : (
            <button
              onClick={onDisconnect}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium bg-cyan-950/70 hover:bg-cyan-900 border border-cyan-700/60 text-cyan-300 transition-colors"
            >
              <Cpu className="w-3.5 h-3.5 animate-pulse text-cyan-400" />
              <span>{connectionMode === 'WEB_SERIAL' ? 'USB Linked' : 'WiFi Linked'} (Disconnect)</span>
            </button>
          )}

          {/* Wiring Guide Button */}
          <button
            onClick={onOpenWiringGuide}
            title="Open Rover Wiring & Components Guide"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-slate-300 transition-colors"
          >
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Wiring Guide</span>
          </button>

          {/* Firmware Code Button */}
          <button
            onClick={onOpenFirmware}
            title="Get ESP32 Arduino C++ Firmware Code"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-slate-300 transition-colors"
          >
            <Code2 className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">ESP32 Code</span>
          </button>

          {/* Emergency Stop Button */}
          <button
            onClick={onEmergencyStop}
            title="EMERGENCY BRAKE - Halts all motors, blades, and pump instantly"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-950/50 active:scale-95 transition-all"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>E-STOP</span>
          </button>
        </div>
      </div>

      {/* Wifi IP prompt popup */}
      {showWifiPrompt && (
        <div className="max-w-7xl mx-auto mt-2 p-2.5 rounded-md bg-slate-900 border border-slate-800 text-xs flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2">
          <form onSubmit={handleWifiSubmit} className="flex items-center gap-2 w-full max-w-md">
            <span className="text-slate-400 font-mono">ws://</span>
            <input
              type="text"
              value={wifiIp}
              onChange={(e) => setWifiIp(e.target.value)}
              placeholder="192.168.4.1"
              className="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200 text-xs font-mono focus:outline-none focus:border-cyan-400 flex-1"
            />
            <span className="text-slate-400 font-mono">:81</span>
            <button
              type="submit"
              className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs transition-colors"
            >
              Connect
            </button>
          </form>
          <button
            onClick={() => setShowWifiPrompt(false)}
            className="text-slate-500 hover:text-slate-300 px-1 text-xs"
          >
            Cancel
          </button>
        </div>
      )}
    </header>
  );
};
