import React, { useEffect, useState } from 'react';
import { TelemetryData } from '../types/agribot';
import { 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight, 
  Square, 
  Gamepad2, 
  RotateCw, 
  Droplets, 
  Sprout, 
  Sliders
} from 'lucide-react';

interface ManualControlsProps {
  telemetry: TelemetryData;
  onDrive: (dir: 'FORWARD' | 'BACKWARD' | 'LEFT' | 'RIGHT' | 'STOP', speed?: number) => void;
  onToggleBlade: () => void;
  onTriggerPump: () => void;
  onTriggerDrill: () => void;
}

export const ManualControls: React.FC<ManualControlsProps> = ({
  telemetry,
  onDrive,
  onToggleBlade,
  onTriggerPump,
  onTriggerDrill,
}) => {
  const [speedPwm, setSpeedPwm] = useState(180);

  // Keyboard navigation support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;

      switch (e.key.toLowerCase()) {
        case 'w':
        case 'arrowup':
          e.preventDefault();
          onDrive('FORWARD', speedPwm);
          break;
        case 's':
        case 'arrowdown':
          e.preventDefault();
          onDrive('BACKWARD', speedPwm);
          break;
        case 'a':
        case 'arrowleft':
          e.preventDefault();
          onDrive('LEFT', speedPwm);
          break;
        case 'd':
        case 'arrowright':
          e.preventDefault();
          onDrive('RIGHT', speedPwm);
          break;
        case ' ':
          e.preventDefault();
          onDrive('STOP');
          break;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;
      if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(e.key.toLowerCase())) {
        onDrive('STOP');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [onDrive, speedPwm]);

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 lg:p-5 shadow-xl space-y-4">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-md bg-purple-500/10 border border-purple-500/30 text-purple-400">
            <Gamepad2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100">
              Manual Teleoperation & Direct Actuator Overrides
            </h3>
            <p className="text-xs text-slate-400">
              Drive with D-Pad or Keyboard (W/A/S/D / Arrows / Space to Brake)
            </p>
          </div>
        </div>

        {/* Speed indicator */}
        <div className="text-right font-mono text-xs">
          <span className="text-slate-400 block text-[10px]">MOTOR SPEED</span>
          <span className="text-purple-400 font-bold">{speedPwm} PWM</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-center">
        {/* Virtual D-Pad */}
        <div className="flex flex-col items-center justify-center p-3 bg-slate-950/60 rounded-xl border border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 mb-2 uppercase tracking-wider">
            L298N 4-Wheel Drive
          </span>

          <div className="grid grid-cols-3 gap-2 w-44">
            <div />
            <button
              onClick={() => onDrive('FORWARD', speedPwm)}
              className="h-12 bg-slate-800 hover:bg-slate-700 active:bg-purple-600 rounded-lg flex items-center justify-center text-slate-200 transition-colors shadow-md border border-slate-700"
              title="Drive Forward (W / ArrowUp)"
            >
              <ArrowUp className="w-5 h-5" />
            </button>
            <div />

            <button
              onClick={() => onDrive('LEFT', speedPwm)}
              className="h-12 bg-slate-800 hover:bg-slate-700 active:bg-purple-600 rounded-lg flex items-center justify-center text-slate-200 transition-colors shadow-md border border-slate-700"
              title="Steer Left (A / ArrowLeft)"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <button
              onClick={() => onDrive('STOP')}
              className="h-12 bg-red-950/80 hover:bg-red-900 border border-red-700 text-red-300 rounded-lg flex items-center justify-center transition-colors shadow-md"
              title="Brake / Halt Motors (Space)"
            >
              <Square className="w-4 h-4 fill-current" />
            </button>

            <button
              onClick={() => onDrive('RIGHT', speedPwm)}
              className="h-12 bg-slate-800 hover:bg-slate-700 active:bg-purple-600 rounded-lg flex items-center justify-center text-slate-200 transition-colors shadow-md border border-slate-700"
              title="Steer Right (D / ArrowRight)"
            >
              <ArrowRight className="w-5 h-5" />
            </button>

            <div />
            <button
              onClick={() => onDrive('BACKWARD', speedPwm)}
              className="h-12 bg-slate-800 hover:bg-slate-700 active:bg-purple-600 rounded-lg flex items-center justify-center text-slate-200 transition-colors shadow-md border border-slate-700"
              title="Drive Reverse (S / ArrowDown)"
            >
              <ArrowDown className="w-5 h-5" />
            </button>
            <div />
          </div>
        </div>

        {/* Speed Slider & Motor Feedback */}
        <div className="space-y-4 p-3 bg-slate-950/60 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-200 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-purple-400" />
              Drive Throttle (PWM)
            </span>
            <span className="font-mono text-purple-400 font-bold">{speedPwm} / 255</span>
          </div>

          <input
            type="range"
            min="60"
            max="255"
            step="5"
            value={speedPwm}
            onChange={(e) => setSpeedPwm(parseInt(e.target.value, 10))}
            className="w-full accent-purple-500 cursor-pointer"
          />

          <div className="flex justify-between text-[10px] font-mono text-slate-500">
            <span>60 (Slow Crawl)</span>
            <span>180 (Standard)</span>
            <span>255 (Full Speed)</span>
          </div>

          {/* Motor telemetry readouts */}
          <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block">LEFT MOTORS (OUT1/2)</span>
              <span className="font-bold text-slate-200">{telemetry.motorLeftPwm} PWM</span>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-[10px] text-slate-400 block">RIGHT MOTORS (OUT3/4)</span>
              <span className="font-bold text-slate-200">{telemetry.motorRightPwm} PWM</span>
            </div>
          </div>
        </div>

        {/* Direct Actuator Trigger Buttons */}
        <div className="space-y-2 p-3 bg-slate-950/60 rounded-xl border border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 block mb-1 uppercase tracking-wider">
            Interchangeable Tool Direct Triggers
          </span>

          {/* Front Harvester Blade */}
          <button
            onClick={onToggleBlade}
            className={`w-full py-2 px-3 rounded-lg text-xs font-medium border flex items-center justify-between transition-colors ${
              telemetry.harvesterBladeActive
                ? 'bg-amber-950 text-amber-200 border-amber-600'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700'
            }`}
          >
            <span className="flex items-center gap-2">
              <RotateCw className={`w-3.5 h-3.5 text-amber-400 ${telemetry.harvesterBladeActive ? 'animate-spin' : ''}`} />
              Front Harvester Blades
            </span>
            <span className="font-mono text-[10px] uppercase font-bold">
              {telemetry.harvesterBladeActive ? 'RUNNING' : 'OFF'}
            </span>
          </button>

          {/* 12V Water Pump */}
          <button
            onClick={onTriggerPump}
            className={`w-full py-2 px-3 rounded-lg text-xs font-medium border flex items-center justify-between transition-colors ${
              telemetry.pumpActive
                ? 'bg-cyan-950 text-cyan-200 border-cyan-600'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700'
            }`}
          >
            <span className="flex items-center gap-2">
              <Droplets className="w-3.5 h-3.5 text-cyan-400" />
              12V Water Pump Relay
            </span>
            <span className="font-mono text-[10px] uppercase font-bold">
              {telemetry.pumpActive ? 'PUMPING' : 'PULSE 2s'}
            </span>
          </button>

          {/* Seed Drill Servo */}
          <button
            onClick={onTriggerDrill}
            className={`w-full py-2 px-3 rounded-lg text-xs font-medium border flex items-center justify-between transition-colors ${
              telemetry.seedDrillActive
                ? 'bg-emerald-950 text-emerald-200 border-emerald-600'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700'
            }`}
          >
            <span className="flex items-center gap-2">
              <Sprout className="w-3.5 h-3.5 text-emerald-400" />
              Seed Drill Servo (Pin D9)
            </span>
            <span className="font-mono text-[10px] uppercase font-bold">
              {telemetry.seedDrillActive ? 'PLUNGED' : 'DROP SEED'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
