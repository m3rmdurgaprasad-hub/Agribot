import React from 'react';
import { BotMode } from '../types/agribot';
import { Sprout, Wheat, Droplets, Gamepad2, PauseCircle } from 'lucide-react';

interface ModeSelectorProps {
  currentMode: BotMode;
  onSelectMode: (mode: BotMode) => void;
}

export const ModeSelector: React.FC<ModeSelectorProps> = ({ currentMode, onSelectMode }) => {
  const modes: Array<{
    id: BotMode;
    title: string;
    subtitle: string;
    badge: string;
    badgeColor: string;
    icon: React.ReactNode;
    features: string[];
    accentBorder: string;
    activeBg: string;
  }> = [
    {
      id: 'PLOUGH_SEED',
      title: 'Plough & Precision Seeder',
      subtitle: 'Distance calculation, zero-motor drill plunge & auto-moisture irrigation',
      badge: 'Autonomous Seeding',
      badgeColor: 'text-emerald-400 bg-emerald-950/60 border-emerald-800',
      icon: <Sprout className="w-5 h-5 text-emerald-400" />,
      features: [
        'Calculates distance between seed sites',
        'Stops drive motors during drill plunge (0 RPM)',
        'Actuates seed drill servo into furrow',
        'Monitors soil moisture & auto-triggers 12V pump',
      ],
      accentBorder: 'border-emerald-500 shadow-emerald-950/40 shadow-lg',
      activeBg: 'bg-emerald-950/30 border-emerald-500/80',
    },
    {
      id: 'HARVEST',
      title: 'Harvesting System',
      subtitle: 'Front motor rotating blades, swath collection & collision guard',
      badge: 'Cutter Blades Active',
      badgeColor: 'text-amber-400 bg-amber-950/60 border-amber-800',
      icon: <Wheat className="w-5 h-5 text-amber-400" />,
      features: [
        'Runs front high-torque harvester motor blades',
        'PWM speed control (up to 1800 RPM)',
        'Precision forward crop harvesting crawl',
        'Ultrasonic obstacle automatic safety freeze',
      ],
      accentBorder: 'border-amber-500 shadow-amber-950/40 shadow-lg',
      activeBg: 'bg-amber-950/30 border-amber-500/80',
    },
    {
      id: 'IRRIGATION_ONLY',
      title: 'Smart Furrow Irrigation',
      subtitle: 'Targeted moisture replenishment via 12V pump relay',
      badge: '12V Pump Module',
      badgeColor: 'text-cyan-400 bg-cyan-950/60 border-cyan-800',
      icon: <Droplets className="w-5 h-5 text-cyan-400" />,
      features: [
        'Stationary deep-furrow watering cycle',
        'Continuous capacitive soil sensor readout',
        'Configurable spray volume per furrow meter',
      ],
      accentBorder: 'border-cyan-500 shadow-cyan-950/40 shadow-lg',
      activeBg: 'bg-cyan-950/30 border-cyan-500/80',
    },
    {
      id: 'MANUAL',
      title: 'Manual Teleoperation',
      subtitle: 'Direct joystick drive and individual actuator overrides',
      badge: 'Full Pilot Control',
      badgeColor: 'text-purple-400 bg-purple-950/60 border-purple-800',
      icon: <Gamepad2 className="w-5 h-5 text-purple-400" />,
      features: [
        'Virtual D-Pad & keyboard steering (WASD)',
        'Manual blade spin & drill test triggers',
        'PWM motor power slider (0 - 255)',
      ],
      accentBorder: 'border-purple-500 shadow-purple-950/40 shadow-lg',
      activeBg: 'bg-purple-950/30 border-purple-500/80',
    },
    {
      id: 'IDLE',
      title: 'Rover Standby',
      subtitle: 'Hold rover stationary while charging via 10W solar panel',
      badge: 'Zero Power Draw',
      badgeColor: 'text-slate-400 bg-slate-900 border-slate-700',
      icon: <PauseCircle className="w-5 h-5 text-slate-400" />,
      features: [
        'All drive motors & actuators disengaged',
        'Continuous telemetry transmission',
        'Solar charging optimization',
      ],
      accentBorder: 'border-slate-600',
      activeBg: 'bg-slate-900/60 border-slate-600',
    },
  ];

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            Mission Mode Selection
            <span className="text-xs text-slate-400 font-normal">
              · Select automated farming cycle or manual pilot
            </span>
          </h2>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
        {modes.map((mode) => {
          const isActive = currentMode === mode.id;
          return (
            <button
              key={mode.id}
              onClick={() => onSelectMode(mode.id)}
              className={`text-left p-3.5 rounded-lg border transition-all flex flex-col justify-between relative group ${
                isActive
                  ? `${mode.activeBg} ${mode.accentBorder}`
                  : 'bg-slate-900/60 border-slate-800/90 hover:bg-slate-900 hover:border-slate-700'
              }`}
            >
              <div>
                {/* Header line */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="p-2 rounded-md bg-slate-950/80 border border-slate-800">
                    {mode.icon}
                  </div>
                  <span
                    className={`text-[11px] font-mono font-medium px-2 py-0.5 rounded border ${mode.badgeColor}`}
                  >
                    {mode.badge}
                  </span>
                </div>

                <h3 className="font-bold text-sm text-slate-100 group-hover:text-white mb-1">
                  {mode.title}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-3">
                  {mode.subtitle}
                </p>
              </div>

              {/* Feature checklist */}
              <ul className="space-y-1 text-[11px] text-slate-300 border-t border-slate-800/80 pt-2.5">
                {mode.features.map((feat, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-emerald-400 font-bold">›</span>
                    <span className="text-slate-300 leading-tight">{feat}</span>
                  </li>
                ))}
              </ul>

              {/* Active Glow Bar */}
              {isActive && (
                <div className="absolute -bottom-px left-4 right-4 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
