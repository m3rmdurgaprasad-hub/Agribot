import React from 'react';
import { TelemetryData, SeedLogEntry } from '../types/agribot';
import { 
  Sprout, 
  Droplets, 
  Ruler, 
  Sliders, 
  CheckCircle2, 
  AlertCircle, 
  Timer, 
  Play, 
  Pause,
  Compass,
  ArrowRight
} from 'lucide-react';

interface PloughSeedControllerProps {
  telemetry: TelemetryData;
  seedLogs: SeedLogEntry[];
  onUpdateSeedSpacing: (cm: number) => void;
  onUpdateMoistureThreshold: (threshold: number) => void;
  onTriggerManualDrill: () => void;
  onTriggerManualPump: () => void;
}

export const PloughSeedController: React.FC<PloughSeedControllerProps> = ({
  telemetry,
  seedLogs,
  onUpdateSeedSpacing,
  onUpdateMoistureThreshold,
  onTriggerManualDrill,
  onTriggerManualPump,
}) => {
  // Determine active step index in the 4-phase sequence
  let activePhaseIndex = 0;
  if (telemetry.ploughPhase === 'DRIVING_TO_DISTANCE') activePhaseIndex = 1;
  else if (telemetry.ploughPhase === 'STOPPED_DRILLING_SEED') activePhaseIndex = 2;
  else if (telemetry.ploughPhase === 'CHECKING_MOISTURE') activePhaseIndex = 3;
  else if (telemetry.ploughPhase === 'AUTO_IRRIGATING') activePhaseIndex = 4;

  const sequenceSteps = [
    {
      step: 1,
      title: 'Calculate Distance & Forward Crawl',
      desc: `Calculating ${telemetry.seedSpacingCm} cm spacing. Motors driving forward.`,
      active: telemetry.ploughPhase === 'DRIVING_TO_DISTANCE',
      motorState: 'DRIVE MOTORS RUNNING (PWM 130)',
      motorColor: 'text-emerald-400',
    },
    {
      step: 2,
      title: 'Motors Stopped & Seed Drill Actuation',
      desc: 'Drive motors completely STOPPED (0 RPM). Servo plunges seed drill into ploughed soil.',
      active: telemetry.ploughPhase === 'STOPPED_DRILLING_SEED',
      motorState: 'MOTORS STOPPED (0 RPM - ZERO CREEP)',
      motorColor: 'text-amber-400 font-bold',
    },
    {
      step: 3,
      title: 'Soil Moisture Sensor Sampling',
      desc: `Reading AO capacitive probe: ${telemetry.soilMoisture}% (Threshold: ${telemetry.moistureThreshold}%).`,
      active: telemetry.ploughPhase === 'CHECKING_MOISTURE',
      motorState: 'MOTORS STOPPED (SAMPLING SOIL)',
      motorColor: 'text-cyan-400',
    },
    {
      step: 4,
      title: 'Automated 12V Furrow Irrigation',
      desc: telemetry.pumpActive 
        ? '💧 Soil below threshold! 12V pump active, spraying furrow.' 
        : 'Moisture adequate or standby.',
      active: telemetry.ploughPhase === 'AUTO_IRRIGATING',
      motorState: telemetry.pumpActive ? 'PUMP ACTIVE (12V RELAY ON)' : 'PUMP STANDBY',
      motorColor: 'text-blue-400 font-bold',
    },
  ];

  return (
    <div className="bg-slate-900/80 border border-emerald-900/50 rounded-xl p-4 lg:p-5 shadow-xl space-y-5">
      {/* Header and status banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3.5">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            <Sprout className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100">
                Precision Plough & Seed Drilling System
              </h3>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-300 font-semibold">
                Autonomous State Machine
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Stepped distance navigation · Stationary drill deposit · Moisture-triggered automated irrigation
            </p>
          </div>
        </div>

        {/* Live Seed Counter and Progress */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="bg-slate-950 px-3 py-1.5 rounded-md border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Seeds Planted</span>
            <span className="text-emerald-400 text-base font-bold">{telemetry.seedCount}</span>
          </div>
          <div className="bg-slate-950 px-3 py-1.5 rounded-md border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Furrow Distance</span>
            <span className="text-slate-200 text-base font-bold">{telemetry.totalDistanceMeters.toFixed(2)}m</span>
          </div>
        </div>
      </div>

      {/* Visual Sequence Pipeline (Addressing User's Exact Requirement) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
          <span className="flex items-center gap-1.5 font-bold text-slate-200">
            <Timer className="w-3.5 h-3.5 text-emerald-400" />
            Active Subroutine Pipeline
          </span>
          <span className="font-mono text-emerald-400 text-[11px]">
            Phase: {telemetry.ploughPhase.replace(/_/g, ' ')}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-2.5">
          {sequenceSteps.map((step) => (
            <div
              key={step.step}
              className={`p-3 rounded-lg border text-xs transition-all relative ${
                step.active
                  ? 'bg-emerald-950/40 border-emerald-500 shadow-lg shadow-emerald-950/50'
                  : 'bg-slate-950/60 border-slate-800/80 opacity-80'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] ${
                  step.active ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}>
                  {step.step}
                </span>
                <span className={`text-[10px] font-mono ${step.motorColor}`}>
                  {step.motorState}
                </span>
              </div>
              <h4 className="font-bold text-slate-200 text-xs mb-1">
                {step.title}
              </h4>
              <p className="text-[11px] text-slate-400 leading-snug">
                {step.desc}
              </p>
              {step.active && (
                <div className="absolute top-0 right-0 -mt-1 -mr-1 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Stepped Distance & Moisture Trigger Configuration Sliders */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
        {/* Distance Spacing Calculator */}
        <div className="p-3.5 rounded-lg bg-slate-950/70 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Ruler className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold text-slate-200">
                Calculated Distance Per Seed Spot
              </span>
            </div>
            <span className="font-mono text-sm font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800">
              {telemetry.seedSpacingCm} cm
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Rover drives forward until exactly {telemetry.seedSpacingCm} cm is reached, halts drive motors completely, and drops the seed drill.
          </p>

          <div className="space-y-1">
            <input
              type="range"
              min="10"
              max="45"
              step="5"
              value={telemetry.seedSpacingCm}
              onChange={(e) => onUpdateSeedSpacing(parseInt(e.target.value, 10))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>10 cm (High Density)</span>
              <span>25 cm (Standard)</span>
              <span>45 cm (Wide Furrow)</span>
            </div>
          </div>

          {/* Current Step Distance Progress Bar */}
          <div className="bg-slate-900 p-2.5 rounded border border-slate-800 text-xs">
            <div className="flex justify-between text-[11px] font-mono text-slate-300 mb-1">
              <span>Traversing Furrow to Next Site:</span>
              <span className="text-emerald-400 font-bold">
                {telemetry.stepDistanceTraveledCm} / {telemetry.seedSpacingCm} cm
              </span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
              <div 
                className="bg-emerald-500 h-2 transition-all duration-300"
                style={{ width: `${Math.min(100, (telemetry.stepDistanceTraveledCm / telemetry.seedSpacingCm) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Moisture Threshold & Automated Irrigation Trigger */}
        <div className="p-3.5 rounded-lg bg-slate-950/70 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Droplets className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold text-slate-200">
                Automated Irrigation Trigger Threshold
              </span>
            </div>
            <span className="font-mono text-sm font-bold text-cyan-400 px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800">
              &lt; {telemetry.moistureThreshold}%
            </span>
          </div>

          <p className="text-xs text-slate-400">
            During seeding, if the AO sensor reads below this threshold, the 12V pump relay triggers automatically to moisten the seedbed.
          </p>

          <div className="space-y-1">
            <input
              type="range"
              min="20"
              max="60"
              step="2"
              value={telemetry.moistureThreshold}
              onChange={(e) => onUpdateMoistureThreshold(parseInt(e.target.value, 10))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>20% (Dry Arid)</span>
              <span>38% (Optimal Loam)</span>
              <span>60% (High Moisture)</span>
            </div>
          </div>

          {/* Current Live Moisture vs Threshold */}
          <div className="bg-slate-900 p-2.5 rounded border border-slate-800 text-xs flex items-center justify-between">
            <div>
              <span className="text-slate-400 block text-[10px]">CURRENT SOIL MOISTURE</span>
              <span className={`text-base font-mono font-bold ${
                telemetry.soilMoisture < telemetry.moistureThreshold ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {telemetry.soilMoisture}%
              </span>
            </div>
            <div className="text-right">
              <span className="text-slate-400 block text-[10px]">12V PUMP RELAY STATUS</span>
              <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded border ${
                telemetry.pumpActive
                  ? 'bg-cyan-950 text-cyan-300 border-cyan-700 animate-pulse'
                  : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}>
                {telemetry.pumpActive ? 'PUMPING WATER' : 'STANDBY'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Manual Actuator Diagnostics & Quick Trigger */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-950/60 rounded-lg border border-slate-800/80 text-xs">
        <div className="flex items-center gap-2 text-slate-400">
          <Sliders className="w-4 h-4 text-emerald-400" />
          <span>Actuator Diagnostics:</span>
          <span className="font-mono text-slate-300">
            Servo: {telemetry.seedDrillActive ? '90° (Plunged)' : '0° (Retracted)'} · Pump: {telemetry.pumpActive ? '12V Active' : '0V Off'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onTriggerManualDrill}
            className="px-3 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 border border-slate-700 text-emerald-300 font-medium transition-colors"
          >
            Test Drill Plunge (Servo D9)
          </button>
          <button
            onClick={onTriggerManualPump}
            className="px-3 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 font-medium transition-colors"
          >
            Pulse 12V Water Pump
          </button>
        </div>
      </div>

      {/* Seed Sites & Irrigation History Log */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="font-semibold text-slate-200">
            Recent Furrow Seed Sites & Moisture Log
          </span>
          <span className="font-mono text-[11px] text-slate-500">
            {seedLogs.length} Records Recorded
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border border-slate-800/80 rounded-lg overflow-hidden">
            <thead className="bg-slate-950/80 text-slate-400 font-mono text-[11px]">
              <tr>
                <th className="p-2 pl-3">Time</th>
                <th className="p-2">Distance</th>
                <th className="p-2">Moisture Readout</th>
                <th className="p-2">Auto-Irrigation Status</th>
                <th className="p-2">Coordinates</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-slate-900/40 font-mono text-[11px]">
              {seedLogs.slice(0, 4).map((entry) => (
                <tr key={entry.id} className="hover:bg-slate-900/80">
                  <td className="p-2 pl-3 text-slate-400">{entry.timestamp}</td>
                  <td className="p-2 text-slate-200">{entry.distanceMeter.toFixed(2)}m</td>
                  <td className="p-2">
                    <span className={entry.moistureAtPlanting < telemetry.moistureThreshold ? 'text-amber-400 font-bold' : 'text-emerald-400'}>
                      {entry.moistureAtPlanting}%
                    </span>
                  </td>
                  <td className="p-2">
                    {entry.irrigated ? (
                      <span className="inline-flex items-center gap-1 text-cyan-400 font-bold">
                        <Droplets className="w-3 h-3 text-cyan-400" />
                        Irrigated ({entry.waterDurationSec}s)
                      </span>
                    ) : (
                      <span className="text-slate-500">Optimal (No spray needed)</span>
                    )}
                  </td>
                  <td className="p-2 text-slate-400">({entry.x}, {entry.y})</td>
                </tr>
              ))}
              {seedLogs.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-4 text-center text-slate-500">
                    No seeding events recorded yet. Start Plough & Seeder mode to begin.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
