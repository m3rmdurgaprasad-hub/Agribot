import React from 'react';
import { TelemetryData } from '../types/agribot';
import { 
  Droplets, 
  Battery, 
  Sun, 
  Radar, 
  Sprout, 
  Layers,
  AlertTriangle,
  Zap
} from 'lucide-react';

interface TelemetryGaugesProps {
  telemetry: TelemetryData;
}

export const TelemetryGauges: React.FC<TelemetryGaugesProps> = ({ telemetry }) => {
  const isMoistureCritical = telemetry.soilMoisture < telemetry.moistureThreshold;
  const isBatteryLow = telemetry.batteryPercent < 25;
  const isObstacleClose = telemetry.ultrasonicDistanceCm < 25;

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      {/* 1. SOIL MOISTURE GAUGE */}
      <div className={`p-3.5 rounded-xl border flex flex-col justify-between transition-colors ${
        isMoistureCritical 
          ? 'bg-amber-950/30 border-amber-800/80' 
          : 'bg-slate-900/80 border-slate-800'
      }`}>
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="text-slate-400 font-medium flex items-center gap-1.5">
            <Droplets className={`w-3.5 h-3.5 ${isMoistureCritical ? 'text-amber-400 animate-pulse' : 'text-emerald-400'}`} />
            Soil Moisture
          </span>
          <span className="text-[10px] font-mono text-slate-500">AO Probe</span>
        </div>

        <div className="my-1.5">
          <div className="flex items-baseline gap-1">
            <span className={`text-2xl font-mono font-extrabold ${isMoistureCritical ? 'text-amber-400' : 'text-emerald-400'}`}>
              {telemetry.soilMoisture}%
            </span>
            <span className="text-xs text-slate-500">VWC</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {isMoistureCritical ? '⚠️ Below threshold (Auto-water)' : 'Adequate moisture'}
          </div>
        </div>

        {/* Moisture progress bar with threshold marker */}
        <div className="relative pt-1">
          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
            <div 
              className={`h-2 transition-all duration-300 ${isMoistureCritical ? 'bg-amber-400' : 'bg-emerald-500'}`}
              style={{ width: `${telemetry.soilMoisture}%` }}
            />
          </div>
          {/* Threshold indicator needle */}
          <div 
            className="absolute -top-1 w-0.5 h-4 bg-cyan-400 z-10"
            style={{ left: `${telemetry.moistureThreshold}%` }}
            title={`Auto-Irrigate Threshold: ${telemetry.moistureThreshold}%`}
          />
        </div>
      </div>

      {/* 2. 12V BATTERY PACK */}
      <div className={`p-3.5 rounded-xl border flex flex-col justify-between transition-colors ${
        isBatteryLow 
          ? 'bg-red-950/30 border-red-800/80' 
          : 'bg-slate-900/80 border-slate-800'
      }`}>
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="text-slate-400 font-medium flex items-center gap-1.5">
            <Battery className={`w-3.5 h-3.5 ${isBatteryLow ? 'text-red-400' : 'text-emerald-400'}`} />
            12V Battery Pack
          </span>
          <span className="text-[10px] font-mono text-slate-500">3S Li-ion</span>
        </div>

        <div className="my-1.5">
          <div className="flex items-baseline gap-1">
            <span className={`text-2xl font-mono font-extrabold ${isBatteryLow ? 'text-red-400' : 'text-slate-100'}`}>
              {telemetry.batteryVoltage.toFixed(1)}V
            </span>
            <span className="text-xs text-emerald-400 font-mono">({Math.round(telemetry.batteryPercent)}%)</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Powers L298N & Motors
          </div>
        </div>

        <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
          <div 
            className={`h-2 transition-all duration-300 ${isBatteryLow ? 'bg-red-500' : 'bg-emerald-500'}`}
            style={{ width: `${telemetry.batteryPercent}%` }}
          />
        </div>
      </div>

      {/* 3. 10W SOLAR PANEL */}
      <div className="p-3.5 rounded-xl border bg-slate-900/80 border-slate-800 flex flex-col justify-between">
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="text-slate-400 font-medium flex items-center gap-1.5">
            <Sun className="w-3.5 h-3.5 text-amber-400" />
            10W Solar Panel
          </span>
          <span className="text-[10px] font-mono text-emerald-400">CHARGING</span>
        </div>

        <div className="my-1.5">
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-mono font-extrabold text-amber-400">
              {telemetry.solarWatts}
            </span>
            <span className="text-xs text-slate-400">Watts</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            +0.65A trickle charge
          </div>
        </div>

        <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
          <div 
            className="h-2 bg-amber-400 transition-all duration-300"
            style={{ width: `${Math.min(100, (telemetry.solarWatts / 10) * 100)}%` }}
          />
        </div>
      </div>

      {/* 4. ULTRASONIC HC-SR04 OBSTACLE RADAR */}
      <div className={`p-3.5 rounded-xl border flex flex-col justify-between transition-colors ${
        isObstacleClose 
          ? 'bg-red-950/30 border-red-800/80 animate-pulse' 
          : 'bg-slate-900/80 border-slate-800'
      }`}>
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="text-slate-400 font-medium flex items-center gap-1.5">
            <Radar className={`w-3.5 h-3.5 ${isObstacleClose ? 'text-red-400' : 'text-cyan-400'}`} />
            Obstacle Distance
          </span>
          <span className="text-[10px] font-mono text-slate-500">HC-SR04</span>
        </div>

        <div className="my-1.5">
          <div className="flex items-baseline gap-1">
            <span className={`text-2xl font-mono font-extrabold ${isObstacleClose ? 'text-red-400' : 'text-cyan-400'}`}>
              {telemetry.ultrasonicDistanceCm}
            </span>
            <span className="text-xs text-slate-400">cm</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {isObstacleClose ? '⚠️ Proximity brake triggered' : 'Forward path clear'}
          </div>
        </div>

        <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
          <div 
            className={`h-2 transition-all duration-300 ${isObstacleClose ? 'bg-red-500' : 'bg-cyan-500'}`}
            style={{ width: `${Math.min(100, (telemetry.ultrasonicDistanceCm / 100) * 100)}%` }}
          />
        </div>
      </div>

      {/* 5. WATER RESERVOIR TANK */}
      <div className="p-3.5 rounded-xl border bg-slate-900/80 border-slate-800 flex flex-col justify-between">
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="text-slate-400 font-medium flex items-center gap-1.5">
            <Droplets className="w-3.5 h-3.5 text-blue-400" />
            Water Reservoir
          </span>
          <span className="text-[10px] font-mono text-slate-500">12V Pump</span>
        </div>

        <div className="my-1.5">
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-mono font-extrabold text-blue-400">
              {Math.round(telemetry.waterTankLevel)}%
            </span>
            <span className="text-xs text-slate-400">Tank</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {telemetry.waterDispensedLiters.toFixed(2)}L sprayed to date
          </div>
        </div>

        <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
          <div 
            className="h-2 bg-blue-500 transition-all duration-300"
            style={{ width: `${telemetry.waterTankLevel}%` }}
          />
        </div>
      </div>

      {/* 6. SEED HOPPER TANK */}
      <div className="p-3.5 rounded-xl border bg-slate-900/80 border-slate-800 flex flex-col justify-between">
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="text-slate-400 font-medium flex items-center gap-1.5">
            <Sprout className="w-3.5 h-3.5 text-emerald-400" />
            Seed Hopper Tank
          </span>
          <span className="text-[10px] font-mono text-slate-500">Servo D9</span>
        </div>

        <div className="my-1.5">
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-mono font-extrabold text-emerald-400">
              {Math.round(telemetry.seedHopperLevel)}%
            </span>
            <span className="text-xs text-slate-400">Capacity</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {telemetry.seedCount} seeds deployed
          </div>
        </div>

        <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
          <div 
            className="h-2 bg-emerald-500 transition-all duration-300"
            style={{ width: `${telemetry.seedHopperLevel}%` }}
          />
        </div>
      </div>
    </div>
  );
};
