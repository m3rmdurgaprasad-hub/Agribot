import React, { useState } from 'react';
import { SerialLog } from '../types/agribot';
import { Terminal, Send, Trash2, ArrowDownCircle, ArrowUpCircle, Info } from 'lucide-react';

interface TerminalLogsProps {
  logs: SerialLog[];
  onSendCommand: (cmd: string) => void;
  onClearLogs?: () => void;
}

export const TerminalLogs: React.FC<TerminalLogsProps> = ({
  logs,
  onSendCommand,
  onClearLogs,
}) => {
  const [inputCmd, setInputCmd] = useState('');
  const [filter, setFilter] = useState<'ALL' | 'RX' | 'TX' | 'SYS'>('ALL');

  const filteredLogs = logs.filter((log) => filter === 'ALL' || log.direction === filter);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputCmd.trim()) {
      onSendCommand(inputCmd.trim());
      setInputCmd('');
    }
  };

  const sendQuickCommand = (cmd: string) => {
    onSendCommand(cmd);
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-xl flex flex-col h-80 justify-between">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2 text-xs">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-slate-200">
            ESP32 Serial &amp; Telemetry Stream (115200 Baud)
          </span>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-1 font-mono text-[10px]">
          {(['ALL', 'RX', 'TX', 'SYS'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-2 py-0.5 rounded transition-colors ${
                filter === f
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Log Feed */}
      <div className="flex-1 overflow-y-auto space-y-1 font-mono text-[11px] p-2 bg-slate-950/80 rounded border border-slate-800/80">
        {filteredLogs.map((log) => (
          <div key={log.id} className="flex items-start gap-2 leading-relaxed">
            <span className="text-slate-600 select-none">{log.timestamp}</span>
            <span
              className={`px-1 rounded text-[10px] font-bold select-none ${
                log.direction === 'RX'
                  ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                  : log.direction === 'TX'
                  ? 'bg-amber-950 text-amber-400 border border-amber-800'
                  : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
              }`}
            >
              {log.direction}
            </span>
            <span
              className={`flex-1 break-all ${
                log.direction === 'RX'
                  ? 'text-cyan-200'
                  : log.direction === 'TX'
                  ? 'text-amber-200'
                  : 'text-slate-300'
              }`}
            >
              {log.message}
            </span>
          </div>
        ))}
        {filteredLogs.length === 0 && (
          <div className="text-slate-600 text-center py-8">
            No serial packets matching filter...
          </div>
        )}
      </div>

      {/* Quick Test Chips & Input Bar */}
      <div className="pt-2 space-y-2">
        <div className="flex items-center gap-1.5 overflow-x-auto text-[10px] font-mono pb-1">
          <span className="text-slate-500 whitespace-nowrap">Quick Test:</span>
          <button
            onClick={() => sendQuickCommand('{"mode":"PLOUGH_SEED"}')}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-300 whitespace-nowrap"
          >
            Plough Mode
          </button>
          <button
            onClick={() => sendQuickCommand('{"mode":"HARVEST"}')}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 whitespace-nowrap"
          >
            Harvest Mode
          </button>
          <button
            onClick={() => sendQuickCommand('{"drive":"FORWARD","speed":180}')}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 whitespace-nowrap"
          >
            Drive Forward
          </button>
          <button
            onClick={() => sendQuickCommand('{"pump":true}')}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 whitespace-nowrap"
          >
            Pump 12V
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <input
            type="text"
            value={inputCmd}
            onChange={(e) => setInputCmd(e.target.value)}
            placeholder='Send serial JSON e.g. {"mode":"PLOUGH_SEED","speed":140}'
            className="flex-1 bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-emerald-500"
          />
          <button
            type="submit"
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs rounded flex items-center gap-1.5 transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
