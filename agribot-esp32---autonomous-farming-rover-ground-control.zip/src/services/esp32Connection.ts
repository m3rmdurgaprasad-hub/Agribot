import { 
  BotMode, 
  ConnectionMode, 
  ConnectionStatus, 
  PloughSeedPhase, 
  RoverSettings, 
  SeedLogEntry, 
  SerialLog, 
  TelemetryData 
} from '../types/agribot';

export class ESP32Service {
  private mode: BotMode = 'IDLE';
  private connectionMode: ConnectionMode = 'SIMULATOR';
  private connectionStatus: ConnectionStatus = 'CONNECTED';
  
  // Real Serial port / WebSocket handles
  private serialPort: any = null;
  private serialReader: any = null;
  private serialWriter: any = null;
  private socket: WebSocket | null = null;

  // Telemetry state
  private telemetry: TelemetryData = {
    soilMoisture: 32, // initially slightly dry so auto-irrigation can trigger visibly!
    moistureThreshold: 38,
    pumpActive: false,
    waterTankLevel: 88,
    waterDispensedLiters: 1.4,

    seedSpacingCm: 15,
    ploughPhase: 'IDLE',
    stepDistanceTraveledCm: 0,
    totalDistanceMeters: 4.8,
    seedDrillActive: false,
    seedDrillAngle: 0,
    seedCount: 32,
    seedHopperLevel: 82,

    harvesterBladeActive: false,
    harvesterBladeRpm: 0,
    harvestCrawlSpeedPwm: 120,
    harvestedAreaSqM: 12.5,

    batteryVoltage: 12.3,
    batteryPercent: 88,
    solarWatts: 7.8,
    solarCharging: true,

    roverSpeedPwm: 0,
    motorLeftPwm: 0,
    motorRightPwm: 0,
    ultrasonicDistanceCm: 85,
    obstacleDetected: false,

    position: {
      x: 35,
      y: 40,
      headingDeg: 90,
    },
    gps: {
      lat: 17.3850,
      lng: 78.4867,
      satellites: 9,
    },
    timestamp: Date.now(),
  };

  private settings: RoverSettings = {
    defaultSeedSpacingCm: 15,
    autoIrrigateMoistureThreshold: 38,
    irrigationDurationSec: 2.0,
    harvesterMaxRpm: 1650,
    obstacleStopDistanceCm: 25,
    esp32IpAddress: '192.168.4.1',
    esp32WsPort: 81,
    serialBaudRate: 115200,
  };

  private seedLogs: SeedLogEntry[] = [
    {
      id: 'seed-1',
      timestamp: new Date(Date.now() - 60000).toLocaleTimeString(),
      distanceMeter: 4.2,
      moistureAtPlanting: 30,
      irrigated: true,
      waterDurationSec: 2.0,
      x: 30,
      y: 40,
    },
    {
      id: 'seed-2',
      timestamp: new Date(Date.now() - 40000).toLocaleTimeString(),
      distanceMeter: 4.35,
      moistureAtPlanting: 31,
      irrigated: true,
      waterDurationSec: 2.0,
      x: 32,
      y: 40,
    },
    {
      id: 'seed-3',
      timestamp: new Date(Date.now() - 20000).toLocaleTimeString(),
      distanceMeter: 4.5,
      moistureAtPlanting: 42,
      irrigated: false,
      waterDurationSec: 0,
      x: 34,
      y: 40,
    },
  ];

  private serialLogs: SerialLog[] = [];
  private telemetryListeners: Array<(data: TelemetryData) => void> = [];
  private logListeners: Array<(log: SerialLog) => void> = [];
  private statusListeners: Array<(status: ConnectionStatus, mode: ConnectionMode) => void> = [];
  private seedLogListeners: Array<(entries: SeedLogEntry[]) => void> = [];

  // Simulation tick loop
  private simInterval: any = null;
  private ploughTimer: any = null;
  private irrigationTimer: any = null;

  constructor() {
    this.startSimulationLoop();
    this.addLog('SYS', 'AgriBot Control System Initialized. Simulator mode active.');
  }

  public getTelemetry(): TelemetryData {
    return { ...this.telemetry };
  }

  public getSettings(): RoverSettings {
    return { ...this.settings };
  }

  public updateSettings(newSettings: Partial<RoverSettings>) {
    this.settings = { ...this.settings, ...newSettings };
    if (newSettings.defaultSeedSpacingCm !== undefined) {
      this.telemetry.seedSpacingCm = newSettings.defaultSeedSpacingCm;
    }
    if (newSettings.autoIrrigateMoistureThreshold !== undefined) {
      this.telemetry.moistureThreshold = newSettings.autoIrrigateMoistureThreshold;
    }
    this.notifyTelemetry();
  }

  public getSeedLogs(): SeedLogEntry[] {
    return [...this.seedLogs];
  }

  public getSerialLogs(): SerialLog[] {
    return [...this.serialLogs];
  }

  public getConnectionInfo() {
    return {
      status: this.connectionStatus,
      mode: this.connectionMode,
      modeName: this.mode,
    };
  }

  public subscribeTelemetry(fn: (data: TelemetryData) => void) {
    this.telemetryListeners.push(fn);
    fn(this.telemetry);
    return () => {
      this.telemetryListeners = this.telemetryListeners.filter((l) => l !== fn);
    };
  }

  public subscribeLogs(fn: (log: SerialLog) => void) {
    this.logListeners.push(fn);
    return () => {
      this.logListeners = this.logListeners.filter((l) => l !== fn);
    };
  }

  public subscribeStatus(fn: (status: ConnectionStatus, mode: ConnectionMode) => void) {
    this.statusListeners.push(fn);
    fn(this.connectionStatus, this.connectionMode);
    return () => {
      this.statusListeners = this.statusListeners.filter((l) => l !== fn);
    };
  }

  public subscribeSeedLogs(fn: (entries: SeedLogEntry[]) => void) {
    this.seedLogListeners.push(fn);
    fn(this.seedLogs);
    return () => {
      this.seedLogListeners = this.seedLogListeners.filter((l) => l !== fn);
    };
  }

  private notifyTelemetry() {
    for (const fn of this.telemetryListeners) {
      fn({ ...this.telemetry });
    }
  }

  private notifyStatus() {
    for (const fn of this.statusListeners) {
      fn(this.connectionStatus, this.connectionMode);
    }
  }

  private notifySeedLogs() {
    for (const fn of this.seedLogListeners) {
      fn([...this.seedLogs]);
    }
  }

  public addLog(direction: 'RX' | 'TX' | 'SYS', message: string) {
    const entry: SerialLog = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toLocaleTimeString(),
      direction,
      message,
    };
    this.serialLogs.unshift(entry);
    if (this.serialLogs.length > 100) this.serialLogs.pop();
    for (const fn of this.logListeners) {
      fn(entry);
    }
  }

  // Set Operational Mode
  public setMode(newMode: BotMode) {
    this.mode = newMode;
    this.addLog('TX', `CMD:SET_MODE:${newMode}`);

    // Cancel ongoing plough subroutines if leaving Plough mode
    if (newMode !== 'PLOUGH_SEED') {
      if (this.ploughTimer) clearTimeout(this.ploughTimer);
      if (this.irrigationTimer) clearTimeout(this.irrigationTimer);
      this.telemetry.ploughPhase = 'IDLE';
      this.telemetry.seedDrillActive = false;
      this.telemetry.seedDrillAngle = 0;
    }

    if (newMode === 'EMERGENCY_STOP') {
      this.emergencyStop();
      return;
    }

    if (newMode === 'PLOUGH_SEED') {
      // Setup precision stepped plough & seeding
      this.telemetry.harvesterBladeActive = false;
      this.telemetry.harvesterBladeRpm = 0;
      this.addLog('SYS', 'Mode: PLOUGH & SEED DRILL initiated with auto-moisture irrigation.');
      this.runPloughSeedStep();
    } else if (newMode === 'HARVEST') {
      // Setup front harvester blades active
      this.telemetry.ploughPhase = 'IDLE';
      this.telemetry.seedDrillActive = false;
      this.telemetry.harvesterBladeActive = true;
      this.telemetry.harvesterBladeRpm = this.settings.harvesterMaxRpm;
      this.telemetry.roverSpeedPwm = this.telemetry.harvestCrawlSpeedPwm;
      this.telemetry.motorLeftPwm = this.telemetry.harvestCrawlSpeedPwm;
      this.telemetry.motorRightPwm = this.telemetry.harvestCrawlSpeedPwm;
      this.addLog('SYS', `Mode: HARVEST activated. Front harvester blades spinning at ${this.settings.harvesterMaxRpm} RPM.`);
    } else if (newMode === 'MANUAL') {
      this.telemetry.roverSpeedPwm = 0;
      this.telemetry.motorLeftPwm = 0;
      this.telemetry.motorRightPwm = 0;
      this.addLog('SYS', 'Mode: MANUAL teleoperation. Use D-Pad or Key controls.');
    } else if (newMode === 'IRRIGATION_ONLY') {
      this.telemetry.roverSpeedPwm = 0;
      this.telemetry.motorLeftPwm = 0;
      this.telemetry.motorRightPwm = 0;
      this.telemetry.harvesterBladeActive = false;
      this.telemetry.pumpActive = true;
      this.addLog('SYS', 'Mode: SMART IRRIGATION. Activating 12V pump relay.');
    } else if (newMode === 'IDLE') {
      this.telemetry.roverSpeedPwm = 0;
      this.telemetry.motorLeftPwm = 0;
      this.telemetry.motorRightPwm = 0;
      this.telemetry.harvesterBladeActive = false;
      this.telemetry.harvesterBladeRpm = 0;
      this.telemetry.pumpActive = false;
      this.telemetry.seedDrillActive = false;
      this.addLog('SYS', 'Mode: IDLE. Rover stationary.');
    }

    this.sendHardwareCommand({
      mode: newMode,
      seedSpacingCm: this.telemetry.seedSpacingCm,
      moistureThreshold: this.telemetry.moistureThreshold,
    });
    this.notifyTelemetry();
  }

  public getMode(): BotMode {
    return this.mode;
  }

  // --- PLOUGH & SEED STEPPED SEQUENCE ---
  // The user requirement:
  // "if the guy picks plough mode it should use the seed drill but not move the motor
  // and move forward by calculating the amount of distance into the thing for precise seeding operations.
  // also it should check the moisture sensor during the process to trigger automated irrigation when soil conditions fall below threshold."
  private runPloughSeedStep() {
    if (this.mode !== 'PLOUGH_SEED') return;

    // STEP 1: CALCULATE STEP & MOVE FORWARD
    this.telemetry.ploughPhase = 'DRIVING_TO_DISTANCE';
    this.telemetry.stepDistanceTraveledCm = 0;
    this.telemetry.seedDrillActive = false;
    this.telemetry.seedDrillAngle = 0;
    
    // Drive motors forward to cover seed spacing distance (e.g. 15cm)
    const crawlSpeed = 130;
    this.telemetry.roverSpeedPwm = crawlSpeed;
    this.telemetry.motorLeftPwm = crawlSpeed;
    this.telemetry.motorRightPwm = crawlSpeed;

    this.addLog('SYS', `[PLOUGH-SEED] Calculating distance to next seed spot: ${this.telemetry.seedSpacingCm} cm. Motors driving forward...`);
    this.notifyTelemetry();

    // Simulate distance progression over ~2.0 seconds
    const driveSteps = 10;
    const stepInterval = 200; // ms
    let currentStep = 0;

    const driveInterval = setInterval(() => {
      if (this.mode !== 'PLOUGH_SEED') {
        clearInterval(driveInterval);
        return;
      }

      currentStep++;
      const fraction = currentStep / driveSteps;
      this.telemetry.stepDistanceTraveledCm = Math.min(
        this.telemetry.seedSpacingCm, 
        Math.round(fraction * this.telemetry.seedSpacingCm)
      );
      this.telemetry.totalDistanceMeters += (this.telemetry.seedSpacingCm / 100) / driveSteps;

      // Rover advances position on field grid
      const rad = (this.telemetry.position.headingDeg * Math.PI) / 180;
      this.telemetry.position.x = Math.min(95, Math.max(5, this.telemetry.position.x + Math.cos(rad) * 0.4));
      this.telemetry.position.y = Math.min(95, Math.max(5, this.telemetry.position.y + Math.sin(rad) * 0.4));

      // Fluctuating moisture along the furrow
      const moistureVariance = (Math.sin(Date.now() / 3000) * 12) + (Math.random() * 4 - 2);
      this.telemetry.soilMoisture = Math.max(18, Math.min(68, Math.round(33 + moistureVariance)));

      this.notifyTelemetry();

      if (currentStep >= driveSteps) {
        clearInterval(driveInterval);

        // STEP 2: REACHED POINT -> STOP MOTORS & ENGAGE SEED DRILL
        this.telemetry.ploughPhase = 'STOPPED_DRILLING_SEED';
        // CRITICAL USER REQUIREMENT: "not move the motor"
        this.telemetry.roverSpeedPwm = 0;
        this.telemetry.motorLeftPwm = 0;
        this.telemetry.motorRightPwm = 0;

        // Engage seed drill servo mechanism (D9)
        this.telemetry.seedDrillActive = true;
        this.telemetry.seedDrillAngle = 90; // Lower drill into furrow
        this.telemetry.seedCount += 1;
        this.telemetry.seedHopperLevel = Math.max(0, this.telemetry.seedHopperLevel - 0.4);

        this.addLog('TX', `CMD:DRILL_SERVO:DOWN:90 (Motors STOPPED at spacing ${this.telemetry.seedSpacingCm}cm)`);
        this.addLog('SYS', `[PLOUGH-SEED] Reached target spot. Motors STOPPED. Seed drill servo engaged at depth (Seed #${this.telemetry.seedCount}).`);
        this.notifyTelemetry();

        // Hold drill down for 1.2s to plant seed
        this.ploughTimer = setTimeout(() => {
          if (this.mode !== 'PLOUGH_SEED') return;

          // Drill returns to retracted position
          this.telemetry.seedDrillActive = false;
          this.telemetry.seedDrillAngle = 0;
          this.addLog('TX', `CMD:DRILL_SERVO:RETRACT:0`);

          // STEP 3: CHECK MOISTURE SENSOR & AUTOMATED IRRIGATION
          // CRITICAL USER REQUIREMENT:
          // "also it should check the moisture sensor during the process to trigger automated irrigation when soil conditions fall below threshold."
          this.telemetry.ploughPhase = 'CHECKING_MOISTURE';
          this.addLog('SYS', `[PLOUGH-SEED] Sampling Soil Moisture: ${this.telemetry.soilMoisture}% (Threshold: ${this.telemetry.moistureThreshold}%).`);
          this.notifyTelemetry();

          const isDry = this.telemetry.soilMoisture < this.telemetry.moistureThreshold;

          if (isDry) {
            // TRIGGER AUTOMATED IRRIGATION
            this.telemetry.ploughPhase = 'AUTO_IRRIGATING';
            this.telemetry.pumpActive = true;
            this.addLog('TX', `CMD:PUMP:ON (Auto-Irrigate triggered! Moisture ${this.telemetry.soilMoisture}% < ${this.telemetry.moistureThreshold}%)`);
            this.addLog('SYS', `[AUTO-IRRIGATE] 💧 Low moisture detected (${this.telemetry.soilMoisture}%). 12V pump spraying furrow seedbed!`);
            this.notifyTelemetry();

            // Run pump for duration
            this.irrigationTimer = setTimeout(() => {
              if (this.mode !== 'PLOUGH_SEED') return;
              this.telemetry.pumpActive = false;
              this.telemetry.waterTankLevel = Math.max(0, this.telemetry.waterTankLevel - 0.6);
              this.telemetry.waterDispensedLiters += 0.08;
              this.telemetry.soilMoisture = Math.min(85, this.telemetry.soilMoisture + 18); // moisture replenished!
              
              this.addLog('TX', `CMD:PUMP:OFF (Irrigation complete, soil restored to ${this.telemetry.soilMoisture}%)`);
              this.recordSeedEntry(true, this.settings.irrigationDurationSec);
              this.notifyTelemetry();

              // Continue to next spacing cycle after brief pause
              this.ploughTimer = setTimeout(() => {
                this.runPloughSeedStep();
              }, 600);
            }, this.settings.irrigationDurationSec * 1000);

          } else {
            // Moisture is sufficient
            this.addLog('SYS', `[PLOUGH-SEED] Soil moisture adequate (${this.telemetry.soilMoisture}% >= ${this.telemetry.moistureThreshold}%). Irrigation not needed.`);
            this.recordSeedEntry(false, 0);
            this.notifyTelemetry();

            this.ploughTimer = setTimeout(() => {
              this.runPloughSeedStep();
            }, 600);
          }

        }, 1200);

      }
    }, stepInterval);
  }

  private recordSeedEntry(irrigated: boolean, waterSec: number) {
    const entry: SeedLogEntry = {
      id: 'seed-' + Date.now(),
      timestamp: new Date().toLocaleTimeString(),
      distanceMeter: parseFloat(this.telemetry.totalDistanceMeters.toFixed(2)),
      moistureAtPlanting: this.telemetry.soilMoisture,
      irrigated,
      waterDurationSec: waterSec,
      x: Math.round(this.telemetry.position.x),
      y: Math.round(this.telemetry.position.y),
    };
    this.seedLogs.unshift(entry);
    if (this.seedLogs.length > 50) this.seedLogs.pop();
    this.notifySeedLogs();
  }

  // --- HARVEST OPERATIONS ---
  public setHarvesterRpm(rpm: number) {
    this.telemetry.harvesterBladeRpm = rpm;
    if (rpm > 0) {
      this.telemetry.harvesterBladeActive = true;
    } else {
      this.telemetry.harvesterBladeActive = false;
    }
    this.addLog('TX', `CMD:HARVESTER_PWM:${rpm}`);
    this.notifyTelemetry();
  }

  public toggleHarvesterBlade() {
    if (this.telemetry.harvesterBladeActive) {
      this.telemetry.harvesterBladeActive = false;
      this.telemetry.harvesterBladeRpm = 0;
      this.addLog('TX', 'CMD:HARVESTER_BLADE:OFF');
    } else {
      this.telemetry.harvesterBladeActive = true;
      this.telemetry.harvesterBladeRpm = this.settings.harvesterMaxRpm;
      this.addLog('TX', `CMD:HARVESTER_BLADE:ON:${this.settings.harvesterMaxRpm}`);
    }
    this.notifyTelemetry();
  }

  // --- MANUAL DRIVE & ACTUATOR CONTROLS ---
  public manualDrive(direction: 'FORWARD' | 'BACKWARD' | 'LEFT' | 'RIGHT' | 'STOP', speed: number = 180) {
    this.telemetry.roverSpeedPwm = direction === 'STOP' ? 0 : speed;
    
    switch (direction) {
      case 'FORWARD':
        this.telemetry.motorLeftPwm = speed;
        this.telemetry.motorRightPwm = speed;
        break;
      case 'BACKWARD':
        this.telemetry.motorLeftPwm = -speed;
        this.telemetry.motorRightPwm = -speed;
        break;
      case 'LEFT':
        this.telemetry.motorLeftPwm = -Math.round(speed * 0.7);
        this.telemetry.motorRightPwm = speed;
        break;
      case 'RIGHT':
        this.telemetry.motorLeftPwm = speed;
        this.telemetry.motorRightPwm = -Math.round(speed * 0.7);
        break;
      case 'STOP':
      default:
        this.telemetry.motorLeftPwm = 0;
        this.telemetry.motorRightPwm = 0;
        break;
    }

    this.addLog('TX', `CMD:DRIVE:${direction}:${speed}`);
    this.sendHardwareCommand({
      drive: direction,
      speed,
      leftPwm: this.telemetry.motorLeftPwm,
      rightPwm: this.telemetry.motorRightPwm,
    });
    this.notifyTelemetry();
  }

  public manualTriggerPump(durationSec: number = 2.0) {
    this.telemetry.pumpActive = true;
    this.addLog('TX', `CMD:PUMP:PULSE:${durationSec}s`);
    this.notifyTelemetry();

    setTimeout(() => {
      this.telemetry.pumpActive = false;
      this.telemetry.waterTankLevel = Math.max(0, this.telemetry.waterTankLevel - 0.5);
      this.telemetry.waterDispensedLiters += 0.06;
      this.telemetry.soilMoisture = Math.min(90, this.telemetry.soilMoisture + 15);
      this.addLog('TX', 'CMD:PUMP:STOP');
      this.notifyTelemetry();
    }, durationSec * 1000);
  }

  public manualTriggerDrill() {
    this.telemetry.seedDrillActive = true;
    this.telemetry.seedDrillAngle = 90;
    this.telemetry.seedCount += 1;
    this.addLog('TX', 'CMD:DRILL_SERVO:PLUNGE_MANUAL');
    this.notifyTelemetry();

    setTimeout(() => {
      this.telemetry.seedDrillActive = false;
      this.telemetry.seedDrillAngle = 0;
      this.addLog('TX', 'CMD:DRILL_SERVO:RETRACT');
      this.notifyTelemetry();
    }, 1200);
  }

  public emergencyStop() {
    if (this.ploughTimer) clearTimeout(this.ploughTimer);
    if (this.irrigationTimer) clearTimeout(this.irrigationTimer);

    this.mode = 'EMERGENCY_STOP';
    this.telemetry.roverSpeedPwm = 0;
    this.telemetry.motorLeftPwm = 0;
    this.telemetry.motorRightPwm = 0;
    this.telemetry.harvesterBladeActive = false;
    this.telemetry.harvesterBladeRpm = 0;
    this.telemetry.pumpActive = false;
    this.telemetry.seedDrillActive = false;
    this.telemetry.ploughPhase = 'IDLE';

    this.addLog('TX', 'CMD:EMERGENCY_STOP_ALL_ACTUATORS');
    this.addLog('SYS', '🚨 EMERGENCY BRAKE ENGAGED! All motors, blades, and pumps stopped.');
    this.notifyTelemetry();
  }

  // --- WEB SERIAL (USB TO ESP32) ---
  public async connectWebSerial(): Promise<boolean> {
    if (!('serial' in navigator)) {
      this.addLog('SYS', 'Web Serial API is not supported in this browser. Try Chrome/Edge or use WiFi WebSocket.');
      return false;
    }

    try {
      this.connectionStatus = 'CONNECTING';
      this.notifyStatus();
      this.addLog('SYS', 'Requesting Web Serial port (115200 baud)...');

      const port = await (navigator as any).serial.requestPort();
      await port.open({ baudRate: this.settings.serialBaudRate });

      this.serialPort = port;
      this.connectionMode = 'WEB_SERIAL';
      this.connectionStatus = 'CONNECTED';
      this.addLog('SYS', `✅ Connected to ESP32 via USB Serial at ${this.settings.serialBaudRate} baud.`);
      this.notifyStatus();

      this.readSerialStream(port);
      return true;
    } catch (err: any) {
      this.connectionStatus = 'ERROR';
      this.notifyStatus();
      this.addLog('SYS', `Serial connection error: ${err?.message || err}`);
      return false;
    }
  }

  private async readSerialStream(port: any) {
    const textDecoder = new TextDecoderStream();
    const readableStreamClosed = port.readable.pipeTo(textDecoder.writable);
    const reader = textDecoder.readable.getReader();
    this.serialReader = reader;

    let buffer = '';
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        if (value) {
          buffer += value;
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';
          for (const line of lines) {
            const clean = line.trim();
            if (clean) {
              this.handleIncomingPacket(clean);
            }
          }
        }
      }
    } catch (error: any) {
      this.addLog('SYS', `Serial stream disconnected: ${error?.message || error}`);
      this.disconnect();
    }
  }

  // --- WEBSOCKET (WIFI TO ESP32) ---
  public connectWebSocket(ip: string, port: number = 81): Promise<boolean> {
    return new Promise((resolve) => {
      this.connectionStatus = 'CONNECTING';
      this.notifyStatus();
      this.addLog('SYS', `Connecting to ESP32 WebSocket at ws://${ip}:${port}...`);

      try {
        const ws = new WebSocket(`ws://${ip}:${port}`);
        this.socket = ws;

        ws.onopen = () => {
          this.connectionMode = 'WEBSOCKET';
          this.connectionStatus = 'CONNECTED';
          this.addLog('SYS', `✅ Connected to ESP32 via WiFi WebSocket (ws://${ip}:${port})`);
          this.notifyStatus();
          resolve(true);
        };

        ws.onmessage = (event) => {
          this.handleIncomingPacket(event.data);
        };

        ws.onerror = (err) => {
          this.addLog('SYS', `WebSocket connection failed: ${err}`);
          this.connectionStatus = 'ERROR';
          this.notifyStatus();
          resolve(false);
        };

        ws.onclose = () => {
          this.addLog('SYS', 'WebSocket connection closed.');
          this.connectionStatus = 'DISCONNECTED';
          this.notifyStatus();
        };
      } catch (e: any) {
        this.connectionStatus = 'ERROR';
        this.notifyStatus();
        resolve(false);
      }
    });
  }

  public disconnect() {
    if (this.serialReader) {
      try { this.serialReader.cancel(); } catch {}
      this.serialReader = null;
    }
    if (this.serialPort) {
      try { this.serialPort.close(); } catch {}
      this.serialPort = null;
    }
    if (this.socket) {
      try { this.socket.close(); } catch {}
      this.socket = null;
    }
    this.connectionMode = 'SIMULATOR';
    this.connectionStatus = 'CONNECTED';
    this.addLog('SYS', 'Switched back to Internal High-Fidelity Simulator.');
    this.notifyStatus();
  }

  private handleIncomingPacket(raw: string) {
    this.addLog('RX', raw);

    try {
      if (raw.startsWith('{') && raw.endsWith('}')) {
        const data = JSON.parse(raw);
        if (typeof data.moist === 'number') this.telemetry.soilMoisture = data.moist;
        if (typeof data.batt === 'number') this.telemetry.batteryVoltage = data.batt;
        if (typeof data.pump === 'boolean') this.telemetry.pumpActive = data.pump;
        if (typeof data.drill === 'boolean') this.telemetry.seedDrillActive = data.drill;
        if (typeof data.rpm === 'number') this.telemetry.harvesterBladeRpm = data.rpm;
        if (typeof data.ultra === 'number') {
          this.telemetry.ultrasonicDistanceCm = data.ultra;
          this.telemetry.obstacleDetected = data.ultra <= this.settings.obstacleStopDistanceCm;
        }
        if (typeof data.dist === 'number') this.telemetry.totalDistanceMeters = data.dist;
        if (typeof data.seeds === 'number') this.telemetry.seedCount = data.seeds;
        this.notifyTelemetry();
      }
    } catch {
      // not JSON, raw serial string
    }
  }

  private async sendHardwareCommand(cmdObj: any) {
    const jsonStr = JSON.stringify(cmdObj) + '\n';
    
    // Web Serial
    if (this.connectionMode === 'WEB_SERIAL' && this.serialPort && this.serialPort.writable) {
      try {
        const textEncoder = new TextEncoderStream();
        textEncoder.readable.pipeTo(this.serialPort.writable);
        const writer = textEncoder.writable.getWriter();
        await writer.write(jsonStr);
        writer.releaseLock();
      } catch (err) {
        console.error('Serial send error', err);
      }
    }

    // WebSocket
    if (this.connectionMode === 'WEBSOCKET' && this.socket && this.socket.readyState === WebSocket.OPEN) {
      try {
        this.socket.send(jsonStr);
      } catch (err) {
        console.error('WebSocket send error', err);
      }
    }
  }

  // Simulator Physics & Telemetry Heartbeat
  private startSimulationLoop() {
    if (this.simInterval) clearInterval(this.simInterval);

    this.simInterval = setInterval(() => {
      // Solar and battery physics
      if (this.telemetry.solarCharging) {
        this.telemetry.solarWatts = +(7.5 + Math.sin(Date.now() / 6000) * 1.8).toFixed(1);
        if (this.telemetry.roverSpeedPwm === 0 && !this.telemetry.harvesterBladeActive) {
          this.telemetry.batteryPercent = Math.min(100, +(this.telemetry.batteryPercent + 0.02).toFixed(2));
        }
      }

      // Load drain
      if (this.telemetry.harvesterBladeActive) {
        this.telemetry.batteryPercent = Math.max(10, +(this.telemetry.batteryPercent - 0.05).toFixed(2));
        this.telemetry.harvestedAreaSqM = +(this.telemetry.harvestedAreaSqM + 0.04).toFixed(2);
      }

      // Ultrasonic obstacle clearance simulator
      const ultraNoise = (Math.sin(Date.now() / 4000) * 15);
      this.telemetry.ultrasonicDistanceCm = Math.max(12, Math.round(75 + ultraNoise));
      this.telemetry.obstacleDetected = this.telemetry.ultrasonicDistanceCm <= this.settings.obstacleStopDistanceCm;

      // In Harvest mode, advance rover forward along crop row
      if (this.mode === 'HARVEST' && !this.telemetry.obstacleDetected) {
        const rad = (this.telemetry.position.headingDeg * Math.PI) / 180;
        this.telemetry.position.x = Math.min(95, Math.max(5, this.telemetry.position.x + Math.cos(rad) * 0.2));
        this.telemetry.position.y = Math.min(95, Math.max(5, this.telemetry.position.y + Math.sin(rad) * 0.2));
        this.telemetry.totalDistanceMeters += 0.05;
      }

      this.telemetry.timestamp = Date.now();
      this.notifyTelemetry();
    }, 1000);
  }
}

// Singleton export
export const esp32 = new ESP32Service();
