export const ESP32_ARDUINO_FIRMWARE = `/*
 * =====================================================================
 * AgriBot Autonomous Farming Rover - ESP32 / Arduino Firmware
 * Smart Farming & Precision Robotics Control
 * =====================================================================
 * Pinout & Hardware Architecture based on AgriBot Wiring Diagram:
 * - Microcontroller: ESP32 NodeMCU (or Arduino Uno with Serial Bridge)
 * - Motor Driver: L298N Dual H-Bridge (4x DC Geared Motors 12V)
 * - Seed Drill Actuator: MG996R / SG90 Servo (Pin D9 / GPIO 13)
 * - Soil Moisture Sensor: Capacitive/Resistive Sensor (Pin A0 / GPIO 34)
 * - Water Pump: 12V Submersible Pump via Relay module (Pin GPIO 26)
 * - Harvester Blades: Front 12V High-Torque Motor via MOSFET/PWM (Pin GPIO 25)
 * - Obstacle Sensor: HC-SR04 Ultrasonic (Trig: GPIO 14, Echo: GPIO 27)
 * - Power: 12V Battery Pack (L298N 12V in + 5V jumper powering logic)
 * =====================================================================
 */

#include <Arduino.h>
#include <WiFi.h>
#include <ESP32Servo.h>
#include <ArduinoJson.h> // Library: ArduinoJson by Benoit Blanchon

// ---------------- PIN DEFINITIONS (L298N & ACTUATORS) ----------------
// L298N Motor Driver Pins
const int PIN_ENA = 21;  // Speed Motor 1 & 2 (PWM)
const int PIN_IN1 = 19;  // Motor 1 (Front Left) Dir A
const int PIN_IN2 = 18;  // Motor 1 (Front Left) Dir B
const int PIN_IN3 = 5;   // Motor 2 (Rear Left) Dir A
const int PIN_IN4 = 17;  // Motor 2 (Rear Left) Dir B

const int PIN_ENB = 22;  // Speed Motor 3 & 4 (PWM)
const int PIN_IN5 = 16;  // Motor 3 (Front Right) Dir A
const int PIN_IN6 = 4;   // Motor 3 (Front Right) Dir B
const int PIN_IN7 = 2;   // Motor 4 (Rear Right) Dir A
const int PIN_IN8 = 15;  // Motor 4 (Rear Right) Dir B

// Front Harvester Blade Motor (PWM / Relay)
const int PIN_HARVESTER_PWM = 25; 

// Seed Drill Servo (Corresponds to D9 on Arduino Wiring Guide)
const int PIN_SEED_SERVO = 13; 
Servo seedDrillServo;

// 12V Water Pump Relay
const int PIN_PUMP_RELAY = 26;

// Soil Moisture Sensor (Analog A0 on diagram)
const int PIN_SOIL_MOISTURE = 34; 

// HC-SR04 Ultrasonic Sensor
const int PIN_ULTRA_TRIG = 14;
const int PIN_ULTRA_ECHO = 27;

// Battery Voltage Divider (12V to 3.3V safe)
const int PIN_BATTERY_SENSE = 35;

// ---------------- STATE VARIABLES & CONFIG ----------------
enum BotMode { MODE_IDLE, MODE_MANUAL, MODE_PLOUGH_SEED, MODE_HARVEST, MODE_EMERGENCY_STOP };
BotMode currentMode = MODE_IDLE;

int seedSpacingCm = 15;             // Distance step between seed points
int moistureThreshold = 38;         // Auto-irrigate if soil moisture % < threshold
int irrigationDurationMs = 2000;    // Pump burst duration in ms
int harvesterRpm = 0;               // Harvester blade speed (0 - 255 PWM)

unsigned long lastTelemetryTime = 0;
unsigned long lastDistanceTick = 0;
float totalDistanceTraveledM = 0.0;
int seedsPlanted = 0;

// Autonomous Plough-Seed state machine
enum PloughPhase { PS_CALCULATING, PS_DRIVING_STEP, PS_STOP_AND_DRILL, PS_CHECK_MOISTURE, PS_AUTO_IRRIGATING };
PloughPhase ploughPhase = PS_CALCULATING;
unsigned long ploughTimer = 0;

// ---------------- HARDWARE CONTROL FUNCTIONS ----------------

void setRoverMotors(int leftPwm, int rightPwm) {
  // Left Motors (OUT1 & OUT2)
  if (leftPwm > 0) {
    digitalWrite(PIN_IN1, HIGH);
    digitalWrite(PIN_IN2, LOW);
    digitalWrite(PIN_IN3, HIGH);
    digitalWrite(PIN_IN4, LOW);
    analogWrite(PIN_ENA, constrain(leftPwm, 0, 255));
  } else if (leftPwm < 0) {
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, HIGH);
    digitalWrite(PIN_IN3, LOW);
    digitalWrite(PIN_IN4, HIGH);
    analogWrite(PIN_ENA, constrain(-leftPwm, 0, 255));
  } else {
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, LOW);
    digitalWrite(PIN_IN3, LOW);
    digitalWrite(PIN_IN4, LOW);
    analogWrite(PIN_ENA, 0);
  }

  // Right Motors (OUT3 & OUT4)
  if (rightPwm > 0) {
    digitalWrite(PIN_IN5, HIGH);
    digitalWrite(PIN_IN6, LOW);
    digitalWrite(PIN_IN7, HIGH);
    digitalWrite(PIN_IN8, LOW);
    analogWrite(PIN_ENB, constrain(rightPwm, 0, 255));
  } else if (rightPwm < 0) {
    digitalWrite(PIN_IN5, LOW);
    digitalWrite(PIN_IN6, HIGH);
    digitalWrite(PIN_IN7, LOW);
    digitalWrite(PIN_IN8, HIGH);
    analogWrite(PIN_ENB, constrain(-rightPwm, 0, 255));
  } else {
    digitalWrite(PIN_IN5, LOW);
    digitalWrite(PIN_IN6, LOW);
    digitalWrite(PIN_IN7, LOW);
    digitalWrite(PIN_IN8, LOW);
    analogWrite(PIN_ENB, 0);
  }
}

void stopAllMotors() {
  setRoverMotors(0, 0);
}

void engageSeedDrill(bool plunge) {
  if (plunge) {
    // Rotate servo to 90 degrees to lower drill and drop seed
    seedDrillServo.write(90);
  } else {
    // Retract servo to 0 degrees
    seedDrillServo.write(0);
  }
}

void setHarvesterBlade(int pwmVal) {
  analogWrite(PIN_HARVESTER_PWM, constrain(pwmVal, 0, 255));
}

void setWaterPump(bool turnOn) {
  // Active HIGH relay (or adjust if active LOW module)
  digitalWrite(PIN_PUMP_RELAY, turnOn ? HIGH : LOW);
}

int readSoilMoisturePercent() {
  // Read analog value from capacitive/resistive sensor (0 - 4095 on ESP32)
  int raw = analogRead(PIN_SOIL_MOISTURE);
  // Invert and map: wet soil low resistance, dry soil high resistance
  int percent = map(raw, 3400, 1200, 0, 100);
  return constrain(percent, 0, 100);
}

float readUltrasonicCm() {
  digitalWrite(PIN_ULTRA_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_ULTRA_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_ULTRA_TRIG, LOW);
  
  long duration = pulseIn(PIN_ULTRA_ECHO, HIGH, 30000); // 30ms timeout (~5m)
  if (duration == 0) return 100.0;
  return duration * 0.034 / 2.0;
}

float readBatteryVoltage() {
  int raw = analogRead(PIN_BATTERY_SENSE);
  // Assuming 10k / 2.2k voltage divider for 12V battery
  float vOut = (raw / 4095.0) * 3.3;
  float vBatt = vOut * ((10.0 + 2.2) / 2.2);
  return vBatt > 1.0 ? vBatt : 12.2; // fallback if pin unpopulated
}

// ---------------- TELEMETRY TRANSMISSION ----------------
void sendTelemetryJSON() {
  StaticJsonDocument<256> doc;
  doc["moist"] = readSoilMoisturePercent();
  doc["batt"] = (int)(readBatteryVoltage() * 10) / 10.0;
  doc["pump"] = (digitalRead(PIN_PUMP_RELAY) == HIGH);
  doc["drill"] = (seedDrillServo.read() > 45);
  doc["rpm"] = harvesterRpm * 7; // approximate blade RPM
  doc["ultra"] = (int)readUltrasonicCm();
  doc["dist"] = (int)(totalDistanceTraveledM * 10) / 10.0;
  doc["seeds"] = seedsPlanted;
  doc["mode"] = currentMode;

  serializeJson(doc, Serial);
  Serial.println();
}

// ---------------- PARSE WEB COMMANDS ----------------
void parseCommand(String cmd) {
  StaticJsonDocument<256> doc;
  DeserializationError err = deserializeJson(doc, cmd);
  if (err) return;

  if (doc.containsKey("mode")) {
    const char* m = doc["mode"];
    if (strcmp(m, "PLOUGH_SEED") == 0) {
      currentMode = MODE_PLOUGH_SEED;
      ploughPhase = PS_CALCULATING;
      setHarvesterBlade(0);
    } else if (strcmp(m, "HARVEST") == 0) {
      currentMode = MODE_HARVEST;
      harvesterRpm = 220;
      setHarvesterBlade(harvesterRpm);
      setRoverMotors(110, 110); // slow crawl
    } else if (strcmp(m, "MANUAL") == 0) {
      currentMode = MODE_MANUAL;
      stopAllMotors();
      setHarvesterBlade(0);
    } else if (strcmp(m, "EMERGENCY_STOP") == 0) {
      currentMode = MODE_EMERGENCY_STOP;
      stopAllMotors();
      setHarvesterBlade(0);
      setWaterPump(false);
      engageSeedDrill(false);
    } else if (strcmp(m, "IDLE") == 0) {
      currentMode = MODE_IDLE;
      stopAllMotors();
      setHarvesterBlade(0);
      setWaterPump(false);
    }
  }

  if (doc.containsKey("seedSpacingCm")) {
    seedSpacingCm = doc["seedSpacingCm"];
  }
  if (doc.containsKey("moistureThreshold")) {
    moistureThreshold = doc["moistureThreshold"];
  }

  // Manual drive
  if (doc.containsKey("drive")) {
    const char* dir = doc["drive"];
    int spd = doc["speed"] | 180;
    if (strcmp(dir, "FORWARD") == 0) setRoverMotors(spd, spd);
    else if (strcmp(dir, "BACKWARD") == 0) setRoverMotors(-spd, -spd);
    else if (strcmp(dir, "LEFT") == 0) setRoverMotors(-spd/2, spd);
    else if (strcmp(dir, "RIGHT") == 0) setRoverMotors(spd, -spd/2);
    else stopAllMotors();
  }
}

// ---------------- ARDUINO SETUP & LOOP ----------------

void setup() {
  Serial.begin(115200);
  delay(500);

  // Setup motor pins
  pinMode(PIN_ENA, OUTPUT);
  pinMode(PIN_IN1, OUTPUT);
  pinMode(PIN_IN2, OUTPUT);
  pinMode(PIN_IN3, OUTPUT);
  pinMode(PIN_IN4, OUTPUT);
  pinMode(PIN_ENB, OUTPUT);
  pinMode(PIN_IN5, OUTPUT);
  pinMode(PIN_IN6, OUTPUT);
  pinMode(PIN_IN7, OUTPUT);
  pinMode(PIN_IN8, OUTPUT);
  stopAllMotors();

  // Harvester & Pump
  pinMode(PIN_HARVESTER_PWM, OUTPUT);
  pinMode(PIN_PUMP_RELAY, OUTPUT);
  digitalWrite(PIN_PUMP_RELAY, LOW);

  // Seed Drill Servo (Pin D9)
  seedDrillServo.attach(PIN_SEED_SERVO);
  seedDrillServo.write(0);

  // Ultrasonic
  pinMode(PIN_ULTRA_TRIG, OUTPUT);
  pinMode(PIN_ULTRA_ECHO, INPUT);

  Serial.println("{\\"status\\":\\"AgriBot ESP32 Initialized\\"}");
}

void loop() {
  // Read Serial Commands from Web Dashboard
  if (Serial.available()) {
    String input = Serial.readStringUntil('\\n');
    input.trim();
    if (input.length() > 0) {
      parseCommand(input);
    }
  }

  // 1. OBSTACLE SAFETY CHECK (HC-SR04)
  float obstacleDist = readUltrasonicCm();
  if (obstacleDist < 20.0 && currentMode != MODE_IDLE) {
    stopAllMotors(); // Safety freeze if obstacle in path
  }

  // 2. PLOUGH & PRECISION SEEDING MODE
  // "if the guy picks plough mode it should use the seed drill but not move the motor
  // and move forward by calculating the amount of distance into the thing for precise seeding operations.
  // also it should check the moisture sensor during the process to trigger automated irrigation when soil conditions fall below threshold."
  if (currentMode == MODE_PLOUGH_SEED) {
    switch (ploughPhase) {
      case PS_CALCULATING:
        // Calculate step & commence forward crawl
        ploughTimer = millis();
        setRoverMotors(130, 130);
        ploughPhase = PS_DRIVING_STEP;
        break;

      case PS_DRIVING_STEP:
        // Move forward precisely by calculated distance (time-calibrated or encoder)
        if (millis() - ploughTimer >= 1800) { // Traversed seedSpacingCm (e.g. 15cm)
          totalDistanceTraveledM += (seedSpacingCm / 100.0);
          
          // STOP MOTOR COMPLETELY ("not move the motor")
          stopAllMotors();
          
          // ENGAGE SEED DRILL MECHANISM
          engageSeedDrill(true); // lower servo into furrow
          seedsPlanted++;
          ploughTimer = millis();
          ploughPhase = PS_STOP_AND_DRILL;
        }
        break;

      case PS_STOP_AND_DRILL:
        // Hold servo down for seed deposit (1.2 seconds)
        if (millis() - ploughTimer >= 1200) {
          engageSeedDrill(false); // retract servo arm
          ploughPhase = PS_CHECK_MOISTURE;
        }
        break;

      case PS_CHECK_MOISTURE:
        // CHECK MOISTURE SENSOR
        {
          int moisture = readSoilMoisturePercent();
          if (moisture < moistureThreshold) {
            // TRIGGER AUTOMATED IRRIGATION!
            setWaterPump(true);
            ploughTimer = millis();
            ploughPhase = PS_AUTO_IRRIGATING;
          } else {
            // Soil is wet enough, proceed to next point
            ploughPhase = PS_CALCULATING;
          }
        }
        break;

      case PS_AUTO_IRRIGATING:
        // Keep pump running for designated irrigation duration
        if (millis() - ploughTimer >= irrigationDurationMs) {
          setWaterPump(false);
          ploughPhase = PS_CALCULATING; // resume next furrow distance step
        }
        break;
    }
  }

  // 3. HARVEST MODE
  // "Then is harvest mode it should run the front motor harvester blades"
  if (currentMode == MODE_HARVEST) {
    setHarvesterBlade(220); // Front motor harvester blades spinning!
    // Maintain steady forward cutting crawl
    if (obstacleDist >= 20.0) {
      setRoverMotors(110, 110);
      totalDistanceTraveledM += 0.002;
    } else {
      stopAllMotors();
    }
  }

  // 4. PERIODIC TELEMETRY BROADCAST (Every 500ms)
  if (millis() - lastTelemetryTime >= 500) {
    lastTelemetryTime = millis();
    sendTelemetryJSON();
  }
}
`;
