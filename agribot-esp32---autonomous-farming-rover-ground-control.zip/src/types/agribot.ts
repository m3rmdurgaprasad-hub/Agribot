export type BotMode = 
  | 'IDLE' 
  | 'MANUAL' 
  | 'PLOUGH_SEED' 
  | 'HARVEST' 
  | 'IRRIGATION_ONLY' 
  | 'EMERGENCY_STOP';

export type ConnectionMode = 'SIMULATOR' | 'WEB_SERIAL' | 'WEBSOCKET' | 'HTTP_REST';
export type ConnectionStatus = 'DISCONNECTED' | 'CONNECTING' | 'CONNECTED' | 'ERROR';

export type PloughSeedPhase = 
  | 'IDLE' 
  | 'CALCULATING_STEP' 
  | 'DRIVING_TO_DISTANCE' 
  | 'STOPPED_DRILLING_SEED' 
  | 'CHECKING_MOISTURE' 
  | 'AUTO_IRRIGATING';

export interface TelemetryData {
  // Soil & Irrigation
  soilMoisture: number; // 0 - 100%
  moistureThreshold: number; // trigger auto-irrigation below this (e.g. 35%)
  pumpActive: boolean; // 12V water pump relay
  waterTankLevel: number; // 0 - 100%
  waterDispensedLiters: number;

  // Ploughing & Seeding
  seedSpacingCm: number; // spacing between seeds (e.g. 15 cm)
  ploughPhase: PloughSeedPhase;
  stepDistanceTraveledCm: number; // progress toward current seed point
  totalDistanceMeters: number; // overall rover travel
  seedDrillActive: boolean; // servo arm lowered / dispensing seed
  seedDrillAngle: number; // servo angle (0 - 90 deg)
  seedCount: number; // total seeds planted
  seedHopperLevel: number; // 0 - 100%

  // Harvest System
  harvesterBladeActive: boolean; // front motor running
  harvesterBladeRpm: number; // 0 - 1800 RPM
  harvestCrawlSpeedPwm: number; // 60 - 255
  harvestedAreaSqM: number; // square meters harvested

  // Power & Environment
  batteryVoltage: number; // e.g. 12.2 V
  batteryPercent: number; // 0 - 100%
  solarWatts: number; // 0 - 12 W
  solarCharging: boolean;

  // Rover Motion & Sensors
  roverSpeedPwm: number; // 0 - 255
  motorLeftPwm: number;
  motorRightPwm: number;
  ultrasonicDistanceCm: number; // HC-SR04 obstacle distance
  obstacleDetected: boolean;

  // Spatial & Grid
  position: {
    x: number; // 0 - 100 field grid
    y: number; // 0 - 100 field grid
    headingDeg: number; // 0 - 360
  };
  gps: {
    lat: number;
    lng: number;
    satellites: number;
  };

  timestamp: number;
}

export interface SeedLogEntry {
  id: string;
  timestamp: string;
  distanceMeter: number;
  moistureAtPlanting: number;
  irrigated: boolean;
  waterDurationSec: number;
  x: number;
  y: number;
}

export interface SerialLog {
  id: string;
  timestamp: string;
  direction: 'RX' | 'TX' | 'SYS';
  message: string;
}

export interface RoverSettings {
  defaultSeedSpacingCm: number;
  autoIrrigateMoistureThreshold: number;
  irrigationDurationSec: number;
  harvesterMaxRpm: number;
  obstacleStopDistanceCm: number;
  esp32IpAddress: string;
  esp32WsPort: number;
  serialBaudRate: number;
}
